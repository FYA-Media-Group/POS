<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<?php
	
	$strStoreID = $_POST["StoreID"];
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{	
		echo $strStoreID;
	}
?>