<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>


<?php
		$DB = Connect();
		$sql = "Select EmployeeCode from tblEmployees where Status='0'";
		// echo $sql;
		$RS = $DB->query($sql);
		if ($RS->num_rows > 0) 
		{
			while($row = $RS->fetch_assoc())
			{
				$counter ++;
				$strEmployeeCode = $row["EmployeeCode"];
				// echo $strEmployeeCode;
				$pqr="Insert into tblEmployeesRecords (EmployeeCode, DateOfAttendance, Status) Values ('$strEmployeeCode', now(), 0)";
				echo $pqr;
				echo "<br>";
				if ($DB->query($pqr) === TRUE) 
				{
						// echo "Record Update successfully.";
				}
				else
				{
					echo "Error2";
				}
			}
		}
?>