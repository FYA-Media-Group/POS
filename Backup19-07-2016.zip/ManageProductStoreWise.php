<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>


<?php
	$strPageTitle = "Product Management | Nailspa";
	$strDisplayTitle = "Manage Product for Nailspa";
	$strMenuID = "3";
	$strMyTable = "tblProducts";
	$strMyTableID = "ProductID";
	$strMyField = "ProductUniqueCode";
	$strMyActionPage = "ManageProductDetailsStoreWise.php";
	$strMessage = "";
	$sqlColumn = "";
	$sqlColumnValues = "";
	
// code for not allowing the normal admin to access the super admin rights	
if($strAdminType!="0")
{
	die("Sorry you are trying to enter Unauthorized access");
}
// code for not allowing the normal admin to access the super admin rights	

	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$strStep = Filter($_POST["step"]);
		if($strStep=="add")
		{				
			$strProductUniqueCode = Filter($_POST["ProductUniqueCode"]);
			$strProductName = Filter($_POST["ProductName"]);
			$strProductDescription = Filter($_POST["ProductDescription"]);			
			$strStoreID = Filter($_POST["StoreID"]);
			$strStatus = Filter($_POST["Status"]);
			
			$DB = Connect();
			$sql = "Select $strMyTableID from $strMyTable where $strMyField='$_POST[$strMyField]'";
			$RS = $DB->query($sql);
			if ($RS->num_rows > 0) 
			{
				$DB->close();
				die('<div class="alert alert-warning alert-dismissible fade in" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">�</span>
						</button>
						<strong>The Product code already exists in the system.</strong>
					</div>');
				die("");
			}
			else
			{		
				$sqlInsert = "Insert into $strMyTable (ProductUniqueCode, ProductName, ProductDescription, Status, StoreID) values
				('".$strProductUniqueCode."', '".$strProductName."', '".$strProductDescription."', '".$strStatus."', '".$strStoreID."')";
		
				if ($DB->query($sqlInsert) === TRUE) 
				{
					$last_id = $DB->insert_id;
				}
				else
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
				$filepath = 'imageupload/images';
				CreateFolder($filepath);
				
				$strValidateImage1 = trim(ValidateImageFile2($_FILES, "ImageURL", UniqueStamp()."0".$_FILES["ImageURL"]["name"], $filepath));
				if($strValidateImage1=="Saved successfully")
				{
					// for First Image
					$filename1 = $_FILES["ImageURL"]["name"];
					
					$uploadFilename1 = UniqueStamp()."0".$filename1;		
					$strImageUploadPath1 = $filepath."/".$uploadFilename1;
					// #######################
				}
				else
				{
					die($strValidateImage1);
				}
				$sql1 = "Insert into tblProductsImages (ImageURL, ProductID,  Priority, IsPrimary, Status) Values ('$strImageUploadPath1','$last_id',  '0', '0', '0')";
				ExecuteNQ($sql1);
				
				$DB->Close();
				die('<div class="alert alert-close alert-success">
						<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
						<div class="alert-content">
							<h4 class="alert-title">Record Added Successfully</h4>
							<p>&nbsp;</p>
						</div>
					</div>');
			}
		}
			
			
		if($strStep=="edit")
		{
			$ProductID = Filter($_POST["ProductID"]);
			$ProductUniqueCode = Filter($_POST["ProductUniqueCode"]);
			$ProductName = Filter($_POST["ProductName"]);
			$ProductDescription = HTMLDecode($_POST["ProductDescription"]);
			$Status = Filter($_POST["Status"]);
			$StoreID = Filter($_POST["StoreID"]);
			
			foreach($_POST as $key => $val)
			{
				if($key=="step" || $key==$strMyTableID || $key="ImageURL")
				{
				
				}
				else
				{
					$sqlUpdate = "update $strMyTable set $key='$_POST[$key]' where $strMyTableID='".Decode($_POST[$strMyTableID])."'";
					echo "$sqlUpdate";
					die();
					
				}
			}
			$DB->close();
			die('<div class="alert alert-close alert-success">
					<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
					<div class="alert-content">
						<h4 class="alert-title">Record Updated Successfully</h4>
						<p>&nbsp;</p>
					</div>
				</div>');
		}
		die();	
	}	
?>




<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once("incMetaScript.fya"); ?>	
</head>

<body>
	 <div id="sb-site">
        
		<?php require_once("incOpenLayout.fya"); ?>
		
		
        <?php require_once("incLoader.fya"); ?>
		
		<div id="page-wrapper">
			<div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
			<?php require_once("incLeftMenu.fya"); ?>
			
			<div id="page-content-wrapper">
				<div id="page-content">
                    
					<?php require_once("incHeader.fya"); ?>
					
					<div id="page-title">
                        <h2><?=$strDisplayTitle?></h2>
                        <p>Add, edit, delete Product</p>
                    </div>
					
<?php

if(!isset($_GET["uid"]))
{	
?>				
				<div class="panel">
						<div class="panel">
							<div class="panel-body">
								
								<div class="example-box-wrapper">
								
									<span class="form_result">&nbsp; <br>
									</span>
									
									<div class="panel-body">
										<h3 class="title-hero">Choose Store to View Products | Nailspa</h3>
										<div class="example-box-wrapper">
										<?
										$sql1 = "SELECT StoreID, StoreName FROM tblStores where Status=0";
										$RS2 = $DB->query($sql1);
										while($row2 = $RS2->fetch_assoc())
										{
										?>
											<center>
												<div class="item col-lg-4 masonry-2" data-filter-value="masonry-2" style="margin: 20px 50px">
													<?
														$StoreID = $row2['StoreID'];
														$strStoreID = EncodeQ($StoreID);
													?>
													<a href="ManageProductDetailsStoreWise.php?q=<?=$strStoreID?>" title="">
														<div class="thumbnail-box-wrapper">
															<div class="thumbnail-box">
																<img src="images/logo.png" alt="<?=$row2['StoreName']?>">
															</div>
															<div class="thumb-pane">
																<h3 class="thumb-heading animated rollIn"><?=$row2['StoreName']?></h3>
															</div>
														</div>
													</a>
												</div>
											</center>
										<?
										}
										?>
										
										</div>
										<!-- End Table -->							
											
											
										<!--</div>-->
									</div>
								</div>
							</div>
						</div>
                    </div>
<?php
} // End null condition
?>	                   
                </div>
            </div>
        </div>
		
        <?php require_once 'incFooter.fya'; ?>
		
    </div>
</body>

</html>									