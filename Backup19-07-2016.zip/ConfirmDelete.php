<?php
	require_once 'setting.fya';
	$strStep = Filter($_POST["step"]);
	$strID = Decode(Filter($_POST["dataid"]));
	
	if($strStep=="Step4")
	{
		$sqlDelete = "delete from tblAdminRoles where RoleID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step3")
	{
		$sqlDelete = "delete from tblAdmin where AdminID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step5")
	{
		$sqlDelete = "delete from tblAdminMenuMasters where MenuMasterID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step6")
	{
		$sqlDelete = "delete from tblProductStocks where ProductStockID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	if($strStep=="Step7")
	{
		$DB = Connect();
		$sql = "Select ImageURL FROM tblProductsImages where ProductID='".$strID."'";
		$RS = $DB->query($sql);
		if ($RS->num_rows > 0) 
		{
			while($row = $RS->fetch_assoc())
			{
				$Image = $row["ImageURL"];
				unlink($Image);
			}
		}
		$sqlDelete = "delete from tblProducts where ProductID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step8")
	{
		$sqlDelete = "delete from tblStores where StoreID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step9")
	{
		$DB = Connect();
		$sql = "Select ImagePath FROM tblEmployeesImages where EID='".$strID."'";
		$RS = $DB->query($sql);
		if ($RS->num_rows > 0) 
		{
			while($row = $RS->fetch_assoc())
			{
				$Image = $row["ImagePath"];
				unlink($Image);
			}
		}
		
		$sqlDelete1 = "delete from tblEmployeesImages where EID='".$strID."'";
		ExecuteNQ($sqlDelete1);
		$sqlDelete = "delete from tblEmployees where EID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step10")
	{
		$sqlDelete = "delete from tblStoreSalesTarget where STID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step11")
	{
		$sqlDelete = "DELETE FROM tblServices WHERE ServiceID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step12")
	{
		$sqlDelete = "DELETE FROM tblChargeNames WHERE ChargeNameID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step13")
	{
		$sqlDelete = "DELETE FROM tblChargeSets WHERE ChargeSetID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step14")
	{
		$sqlDelete = "DELETE FROM tblOperationsMasters WHERE OMID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step15")
	{
		$sqlDelete = "DELETE FROM tblPages WHERE PageID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step16")
	{
		$sqlDelete = "DELETE FROM tblMenuMaster WHERE MenuID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step17")
	{
		$sqlDelete = "DELETE FROM tblSocial WHERE SocialID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step18")
	{
		$sqlDelete = "DELETE FROM tblCategories WHERE CategoryID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step19")
	{
		$sqlDelete = "DELETE FROM tblWidgetMasters WHERE WidgetMasterID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	else if($strStep=="Step20")
	{
		$sqlDelete = "DELETE FROM tblCustomers WHERE CustomerID='".$strID."'";
		ExecuteNQ($sqlDelete);
	}
	
	
?>