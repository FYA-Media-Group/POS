<?php

// Saif
$CookieAdminUsername="";
$strPageTitle="";
$strAdminUsername="";
$strAdminFullName="";


// Asmita
// $strSubCat="";
// $strSubCatName="";
// $strMainPostCat="";
// $Taginsert="";
// $TimeofPost="";
// $AdminFullName="";

$RoleID="";
$AdminType="";
$AdminFullName="";
$AdminID="";
$AdminPassword="";
$AdminUserName="";
$LastLogin="";



?>