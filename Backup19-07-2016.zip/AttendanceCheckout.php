<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<?php
	
	$strERID1 = Filter($_POST["getERID"]);
	// echo $strERID1;
	// $strERID2= Decode($strERID1);
	// echo $strERID2;
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{	
		// echo $strERID1;
		$DB = Connect();
		
		$sql1 = "Update tblEmployeesRecords set LogoutTime=now() where ERID ='$strERID1'";
		if ($DB->query($sql1) === TRUE) 
		{
			$timesql="Select TIMEDIFF(LogoutTime,LoginTime) as Hour1 from tblEmployeesRecords Where ERID = $strERID1";
			$RS = $DB->query($timesql);
			if ($RS->num_rows > 0) 
			{
				$row = $RS->fetch_assoc();
				$x = $row['Hour1'];
				echo "Completed ".$x." Hours.";
			}
		} 
		else 
		{
			echo "Error: " . $sql1 . "<br>" . $DB->error;
		}
	}
?>