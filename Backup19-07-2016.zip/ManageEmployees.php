<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>


<?php
	$strPageTitle = "Employee Management | Nailspa";
	$strDisplayTitle = "Manage Employee Nailspa";
	$strMenuID = "2";
	$strMyTable = "tblEmployees";
	$strMyTableID = "EID";
	$strMyField = "EmployeeCode";
	$strMyActionPage = "ManageEmployees.php";
	$strMessage = "";
	$sqlColumn = "";
	$sqlColumnValues = "";
	
	
// code for not allowing the normal admin to access the super admin rights	
	if($strAdminType!="0")
	{
		die("Sorry you are trying to enter Unauthorized access");
	}
// code for not allowing the normal admin to access the super admin rights	


	
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$strStep = Filter($_POST["step"]);
		if($strStep=="add")
		{	
			
				
			$strEmployeeCode = Filter($_POST["EmployeeCode"]);
			$strStoreID = Filter($_POST["StoreID"]);
			$strEmployeeName = Filter($_POST["EmployeeName"]);				
			$strEmployeeAddress = Filter($_POST["EmployeeAddress"]);
			$strEmployeePincode = Filter($_POST["EmployeePincode"]);
			$strEmployeeEmailID = Filter($_POST["EmployeeEmailID"]);
			$strEmployeeMobileNo = Filter($_POST["EmployeeMobileNo"]);
			$strStatus= Filter($_POST["Status"]);

			$DB = Connect();
			$sql = "Select $strMyTableID from $strMyTable where $strMyField='$_POST[$strMyField]'";
			$RS = $DB->query($sql);
			if ($RS->num_rows > 0) 
			{
				$DB->close();
				die('<div class="alert alert-warning alert-dismissible fade in" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
						</button>
						<strong>The Employee Code already exists in the system.</strong>
					</div>');
				die("");
			}
			else
			{
				$filepath = 'imageupload/images';
				CreateFolder($filepath);
				
				$strValidateImage1 = trim(ValidateImageFile2($_FILES, "ImagePath", UniqueStamp()."0".$_FILES["ImagePath"]["name"], $filepath));
				if($strValidateImage1=="Saved successfully")
				{
					// for First Image
					$filename1 = $_FILES["ImagePath"]["name"];
					
					$uploadFilename1 = UniqueStamp()."0".$filename1;		
					$strImageUploadPath1 = $filepath."/".$uploadFilename1;
					// #######################
				}
				else
				{
					die($strValidateImage1);
				}

				$sqlInsert = "Insert into $strMyTable (EmployeeCode, StoreID, EmployeeName, EmployeeAddress, EmployeePincode, EmployeeEmailID, EmployeeMobileNo, Status) values
				('".$strEmployeeCode."','".$strStoreID."', '".$strEmployeeName."', '".$strEmployeeAddress."', '".$strEmployeePincode."', '".$strEmployeeEmailID."', '".$strEmployeeMobileNo."', '".$strStatus."')";				
				// ExecuteNQ($sqlInsert);
				
				if ($DB->query($sqlInsert) === TRUE) 
				{
					$last_id = $DB->insert_id;
				}
				else
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
				
				$sql1 = "Insert into tblEmployeesImages (ImagePath, EID, Status) Values ('$strImageUploadPath1','$last_id', '0')";
				
				ExecuteNQ($sql1);
				
				$sql2 = "INSERT INTO tblEmployeesRecords(EmployeeCode,DateOfAttendance,Status) VALUES ('$last_id', now(), '0')";
				ExecuteNQ($sql2);

				$DB->close();
				
				die('<div class="alert alert-close alert-success">
					<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
					<div class="alert-content">
						<h4 class="alert-title">Record Added Successfully.</h4>
					</div>
				</div>');
			}
			
		}

		if($strStep=="edit")
		{
			$EmployeeCode = Filter($_POST["EmployeeCode"]);
			$StoreID = Filter($_POST["StoreID"]);
			$EmployeeName = Filter($_POST["EmployeeName"]);
			$EmployeePincode = Filter($_POST["EmployeePincode"]);
			$EmployeeAddress = Filter($_POST["EmployeeAddress"]);
			$EmployeeEmailID = Filter($_POST["EmployeeEmailID"]);
			$EmployeeMobileNo = Filter($_POST["EmployeeMobileNo"]);
			$ImagePath = Filter($_POST["ImagePath"]);
			$Status = Filter($_POST["Status"]);
			
			if(isset($_FILES["ImagePath"]["error"]))
			{
				$strValidateImage1 = trim(ValidateImageFile($_FILES, "ImagePath"));
				if($strValidateImage1=="Saved successfully")
				{
				
					// As the image is valid first select the imagename for previous image
					
					$DB = Connect();
					$sql = "Select ImagePath, EID FROM tblEmployeesImages where $strMyTableID='".Decode($_POST[$strMyTableID])."' ";
					
					$RS = $DB->query($sql);
					if ($RS->num_rows > 0) 
					{
						while($row = $RS->fetch_assoc())
						{
							$strOldImageURL = $row["ImagePath"];	
							$strEID = $row["EID"];
						}
						
						$file = $strOldImageURL;
						unlink($file);
						
						$filepath = 'imageupload/images';
						$filename1 = $_FILES["ImagePath"]["name"];
						
						$uploadFilename1 = UniqueStamp().$filename1;		
						$strImageUploadPath1 = $filepath."/".$uploadFilename1;
						// #######################
						
							
						
						$sqlUpdate = "update tblEmployeesImages set ImagePath='".$strImageUploadPath1."' where $strMyTableID='".Decode($_POST[$strMyTableID])."' ";
						ExecuteNQ($sqlUpdate);
							
						
						echo('<div class="alert alert-success alert-dismissible fade in" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
								</button>
								<strong>Employee Image Updated Successfully</strong>
								</div>');						
					}
					else
					{
						$filepath = 'imageupload/images';
						// for First Image
						$filename1 = $_FILES["ImagePath"]["name"];
						
						$uploadFilename1 = UniqueStamp().$filename1;		
						$strImageUploadPath1 = $filepath."/".$uploadFilename1;
						// #######################
						
						$sql1 = "Insert into tblEmployeesImages (ImagePath, EID, Status) Values ('$strImageUploadPath1','$strEID', '0')";
						ExecuteNQ($sql1);
						
						echo('<div class="alert alert-success alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
							</button>
							<strong>Employee Image Added Successfully</strong>
							</div>');
					}					
					
				}
				else
				{
					die($strValidateImage1);
				}
				foreach($_POST as $key => $val)
				{
					if($key=="step" || $key==$strMyTableID ||  $key=="ImagePath" )
					{
					
					}
					else
					{
						$sqlUpdate = "UPDATE $strMyTable SET $key='$_POST[$key]' WHERE $strMyTableID='".Decode($_POST[$strMyTableID])."'";
						ExecuteNQ($sqlUpdate);
						//echo($sqlUpdate);
					}	
				}
				die('<div class="alert alert-close alert-success">
						<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
						<div class="alert-content">
							<h4 class="alert-title">Record Updated Successfully</h4>
						</div>
					</div>');
			}			
		}
		die();
	}	
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once("incMetaScript.fya"); ?>
</head>

<body>
    <div id="sb-site">
        
		<?php require_once("incOpenLayout.fya"); ?>
		
		
        <?php require_once("incLoader.fya"); ?>
		
        <div id="page-wrapper">
            <div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
            
				<?php require_once("incLeftMenu.fya"); ?>
			
            <div id="page-content-wrapper">
                <div id="page-content">
                    
					<?php require_once("incHeader.fya"); ?>
					

                    <div id="page-title">
                        <h2><?=$strDisplayTitle?></h2>
                        <p>Add, Edit, Delete Employee Details</p>
                    </div>
<?php

if(!isset($_GET["uid"]))
{

?>					
					
                    <div class="panel">
						<div class="panel">
							<div class="panel-body">
								
								<div class="example-box-wrapper">
									<div class="tabs">
										<ul>
											<li><a href="#normal-tabs-1" title="Tab 1">Manage</a></li>
											<li><a href="#normal-tabs-2" title="Tab 2">Add</a></li>
										</ul>
										<div id="normal-tabs-1">
										
											<span class="form_result">&nbsp; <br>
											</span>
											
											<div class="panel-body">
												<h3 class="title-hero">List of Employees Nailspa</h3>
												<div class="example-box-wrapper">
													<table id="datatable-responsive" class="table table-striped table-bordered responsive no-wrap" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th>Name <br> Employee Code </th>
																<th>Store ID</th>
																<th>Address <br> Pincode</th>
																<th>Email ID <br>Mobile No</th>
																<th>Status</th>
																<th>Actions</th>
															</tr>
														</thead>
														<tfoot>
															<tr>
																<th>Name <br> Employee Code </th>
																<th>Store ID</th>
																<th>Address <br> Pincode</th>
																<th>Email ID <br>Mobile No</th>
																<th>Status</th>
																<th>Actions</th>
															</tr>
														</tfoot>
														<tbody>

<?php
//Retrieve And Display Values in a Table
// Create connection And Write Values
$DB = Connect();
$sql = "Select * FROM $strMyTable order by $strMyTableID desc";
$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{
	$counter = 0;

	while($row = $RS->fetch_assoc())
	{
		$counter ++;
		$strEID = $row["EID"];
		$getUID = EncodeQ($strEID);
		$getUIDDelete = Encode($strEID);
		$EmployeeCode = $row["EmployeeCode"];
		$StoreID = $row["StoreID"];
		$EmployeeName = $row["EmployeeName"];
		$EmployeeAddress = $row["EmployeeAddress"];
		$EmployeePincode = $row["EmployeePincode"];
		$EmployeeEmailID = $row["EmployeeEmailID"];
		$EmployeeMobileNo = $row["EmployeeMobileNo"];
		$Status = $row["Status"];

		
		if($Status=="0")
		{
			$Status = "Live";
		}
		else
		{
			$Status = "Offline";
		}
		
?>														
														
															<tr id="my_data_tr_<?=$counter?>">
																<td><b>Name:</b> <?=$EmployeeName?> <br><b>Code:</b> <?=$EmployeeCode?></td>
																<td><b>Store:</b> <?=$StoreID?></td>
																<td>Address: <?=$EmployeeAddress?> <br>Pincode: <?=$EmployeePincode?> </td>
																<td>Email ID: <?=$EmployeeEmailID?><br>Mobile No: <?=$EmployeeMobileNo?> </td>
																<td><?=$Status?></td>
																<td>
																	<a class="btn btn-link" href="<?=$strMyActionPage?>?uid=<?=$getUID?>">Edit</a>
																	<a class="btn btn-link font-red" font-redhref="javascript:;" onclick="DeleteData('Step9','<?=$getUIDDelete?>', 'Are you sure you want to delete this Employee - <?=$AdminFullName?>?','my_data_tr_<?=$counter?>');">Delete</a><br>
																		<button class="btn btn-default" data-toggle="modal" data-target=".bs-example-modal-sm">Check Target</button>
																			<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
																				<div class="modal-dialog modal-sm">
																					<div class="modal-content">
																						<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
																							<h4 class="modal-title">Target of the Month is</h4></div>
																						<div class="modal-body">
																							<p><?php
																								$DB = Connect();
																								$sql = "SELECT * FROM tblEmployeeTarget where EmployeeCode='$EmployeeCode'";
																								$RS = $DB->query($sql);
																								if ($RS->num_rows > 0) 
																								{

																									while($row = $RS->fetch_assoc())
																									{
																										$ETID = $row["ETID"];
																										$EmployeeCodeTarget = $row["EmployeeCode"];
																										$TargetForMonth = $row["TargetForMonth"];
																										$BaseTarget = $row["BaseTarget"];
																										$Week1 = $row["Week1"];
																										$Week2 = $row["Week2"];
																										$Week3 = $row["Week3"];
																										$Week4 = $row["Week4"];	
																										$Week5 = $row["Week5"];
																										echo "Till Date Target is Rs.".$TargetForMonth."<br>";
																										echo "Minimum Target for this month is Rs".$BaseTarget."<br>";
																										echo "Targetof the this week is is Rs ".$Week1."<br>";
																										// echo $Week2."<br>";
																										// echo $Week3."<br>";
																										// echo $Week4."<br>";
																										// echo $Week5."<br>";			
																									}
																								}		
																							?></p>
																							
																						</div>
																						<div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div>
																					</div>
																				</div>
																			</div>
																</td>
															</tr>
<?php
	}
}
else
{
?>															
															<tr>
																<td></td>
																<td></td>
																<td>No Records Found</td>
																<td></td>
																<td></td>
																<td></td>
															</tr>
														
<?php
}
$DB->close();
?>
														
														</tbody>
													</table>
												</div>
											</div>
										</div>
<!--End Manage Tab Start ADD Tab-->										
										<div id="normal-tabs-2">
											<div class="panel-body">
											<form role="form" class="form-horizontal bordered-row enquiry_form" onSubmit="proceed_formsubmit('.enquiry_form', '<?=$strMyActionPage?>', '.result_message', '', '','', '.imageupload'); return false;">
											
											<span class="result_message">&nbsp; <br>
											</span>
											<input type="hidden" name="step" value="add">

											
												<h3 class="title-hero">Add Employees</h3>
												<div class="example-box-wrapper">
													
<?php
// Create connection And Write Values
$DB = Connect();
$sql = "SHOW COLUMNS FROM ".$strMyTable." ";
$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{

	while($row = $RS->fetch_assoc())
	{
		if($row["Field"]==$strMyTableID)
		{
		}
			
		else if ($row["Field"]=="EmployeeCode")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeCode", "Employee Code", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-4"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeeCode", "Employee Code", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("EmployeeCode", "Employee Code", $row["Field"])?>"></div>
														</div>	
<?php
		}
		else if ($row["Field"]=="StoreID")
		{
			$sql1 = "select * FROM tblStores";
			$RS2 = $DB->query($sql1);
			if ($RS2->num_rows > 0)
			{
?>											
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("StoreID", "Store Name", $row["Field"])?> <span>*</span></label>
												<div class="col-sm-3">
													<select class="form-control required"  name="<?=$row["Field"]?>">
															<option value="" selected>--Select Store--</option>
<?
													while($row2 = $RS2->fetch_assoc())
													{
														$strStoreName = $row2["StoreName"];
														$strStoreID = $row2["StoreID"];
?>
														<option value="<?=$strStoreID?>" ><?=$strStoreName?></option>														
<?php
													}
?>
														</select>
<?php
			}
			else
			{
				echo "Admin Roles are not added. <a href='ManageAdminRoles.php' class='btn btn-link' target='Admin Role'>Click here to Add Admin Roles</a>";
			}
?>
												</div>
											</div>	
<?php
		}
		else if ($row["Field"]=="EmployeeName")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeName", "Full Name", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-4"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeeName", "Full Name", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("EmployeeName", "Full Name", $row["Field"])?>"></div>
														</div>	
<?php
		}
		else if ($row["Field"]=="EmployeeAddress")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeAddress", "Address", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-5" ><textarea rows="05" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeeAddress", "Address", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("EmployeeAddress", "Address", $row["Field"])?>"></textarea></div>
														</div>														
<?php
		}
		else if ($row["Field"]=="EmployeePincode")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeePincode", "Pincode", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-4"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeePincode", "Pincode", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("EmployeePincode", "Pincode", $row["Field"])?>"></div>
														</div>														
<?php
		}
		else if ($row["Field"]=="EmployeeEmailID")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeEmailID", "Email ID", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-4"><input type="email" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeeEmailID", "Email ID", $row["Field"])?>" class="form-control admin_email required" placeholder="<?=str_replace("EmployeeEmailID", "Email ID", $row["Field"])?>"></div>
														</div>														
<?php
		}
		else if ($row["Field"]=="EmployeeMobileNo")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeMobileNo", "Mobile No", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-4"><input type="tel" name="<?=$row["Field"]?>" id="<?=str_replace("EmployeeMobileNo", "Mobile No", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("EmployeeMobileNo", "Mobile No", $row["Field"])?>" pattern="[0-9]{10}" title="Mobile Number should be of only 10 digits."></div>
														</div>														
<?php
		}
		else if ($row["Field"]=="Status")
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Status", "Status", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-3">
																<select name="<?=$row["Field"]?>" class="form-control required">
																	<option value="0" Selected>Live</option>
																	<option value="1">Offline</option>	
																</select>
															</div>
														</div>
<?php	
		}
		else
		{
?>
														<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Admin", " ", $row["Field"])?> <span>*</span></label>
															<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("Admin", " ", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("Admin", " ", $row["Field"])?>"></div>
														</div>
<?php
		}
	}
?>
														
														<div class="form-group"><label class="col-sm-3 control-label">Image Path<span>*</span></label>
															<div class="col-sm-4">
																<input type="file" class="form-control imageupload required" data-source="ImagePath">
															</div>
														</div>
														
														
														
														<div class="form-group"><label class="col-sm-3 control-label"></label>
															<input type="submit" class="btn ra-100 btn-primary" value="Submit">
															
															<div class="col-sm-1"><a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a></div>
														</div>
<?php
}
$DB->close();
?>													
													
												</div>
											</form>
											</div>
											
											
											
										</div>
										
									</div>
								</div>
							</div>
						</div>
                    </div>
<?php
} // End null condition
else
{
?>						
					
					<div class="panel">
						<div class="panel-body">
							<div class="fa-hover">	
								<a class="btn btn-primary btn-lg btn-block" href="<?=$strMyActionPage?>"><i class="fa fa-backward"></i> &nbsp; Go back to <?=$strPageTitle?></a>
							</div>
						
							<div class="panel-body">
							<form role="form" class="form-horizontal bordered-row enquiry_form" onSubmit="proceed_formsubmit('.enquiry_form', '<?=$strMyActionPage?>', '.result_message', '', '.admin_email','', '.imageupload'); return false;">
											
								<span class="result_message">&nbsp; <br>
								</span>
								<br>
								<input type="hidden" name="step" value="edit">

								
									<h3 class="title-hero">Edit Employee Details</h3>
									<div class="example-box-wrapper">
										
<?php

$strID = DecodeQ(Filter($_GET["uid"]));
$DB = Connect();
$sql = "select * FROM $strMyTable where $strMyTableID = '$strID'";
$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{

	while($row = $RS->fetch_assoc())
	{	
		$EmployeeName=$row["EmployeeName"];
		$StoreID=$row["StoreID"];
		$EmployeeAddress=$row["EmployeeAddress"];
		$EmployeePincode=$row["EmployeePincode"];
		$EmployeeEmailID=$row["EmployeeEmailID"];
		$EmployeeMobileNo=$row["EmployeeMobileNo"];
		$Status=$row["Status"];

		foreach($row as $key => $val)
		{
			if($key==$strMyTableID)
			{
?>
											<input type="hidden" name="<?=$key?>" value="<?=Encode($strID)?>">	

<?php
			}
			elseif($key=="EmployeeCode")
			{
?>	
										
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeCode", "Employee Code", $key)?> <span>*</span></label>
												<div class="col-sm-4"><input class="form-control" value="<?=$row[$key]?>" readonly></div>
											</div>

<?php
			}
			elseif($key=="StoreID")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("StoreID", "Store Name", $key)?> <span>*</span></label>
												<div class="col-sm-3">
													<select name="<?=$key?>" class="form-control required">
														<option value="0" Selected>--Select Store--</option>
												<?php		$sql2 = "SELECT StoreName, StoreID FROM tblStores";
															$Res2 = $DB->query($sql2);
															if ($Res2->num_rows > 0) 
															{
																while($row = $Res2->fetch_assoc())
																{
																	$varStoreID = $row['StoreID'];
																	$varStoreName = $row['StoreName'];
																	if($varStoreID == $StoreID)
																	{
																	?>
																		<option value="<?=$varStoreID?>" selected><?=$varStoreName?></option>
															<?		}
																	else
																	{
																	?>
																		<option value="<?=$varStoreID?>"><?=$varStoreName?></option>
															<?		}
																}
															}
													?>						
													</select>
												</div>
											</div>
<?php
			}
			elseif($key=="EmployeeName")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeName", "Full Name", $key)?> <span>*</span></label>
												<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("EmployeeName", "Full Name", $key)?>" value="<?=$EmployeeName?>"></div>
											</div>
<?php
			}
			elseif($key=="EmployeeAddress")
			{
?>

											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeAddress", "Address", $key)?> <span>*</span></label>
												<div class="col-sm-3"><textarea name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("EmployeeAddress", "Address", $key)?>"><?=$EmployeeAddress?></textarea></div>
											</div>
<?php
			}
			elseif($key=="EmployeePincode")
			{
?>

											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeePincode", "Pincode", $key)?> <span>*</span></label>
												<div class="col-sm-4"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("EmployeePincode", "Pincode", $key)?>" value="<?=$EmployeePincode?>"></div>
											</div>
<?php
			}
			elseif($key=="EmployeeEmailID")
			{
?>

											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeEmailID", "Email ID", $key)?> <span>*</span></label>
												<div class="col-sm-4"><input type="email" name="<?=$key?>" class="form-control admin_email required" placeholder="<?=str_replace("EmployeeEmailID", "Email ID", $key)?>" value="<?=$EmployeeEmailID?>"></div>
											</div>
<?php
			}
			elseif($key=="EmployeeMobileNo")
			{
?>

											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("EmployeeMobileNo", "Mobile No", $key)?> <span>*</span></label>
												<div class="col-sm-4"><input type="tel" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("EmployeeMobileNo", "Mobile No", $key)?>" value="<?=$EmployeeMobileNo?>" pattern="[0-9]{10}" title="Mobile Number should be of only 10 digits."></div>
											</div>
<?php
			}
			elseif($key=="Status")
			{
?>
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Admin", " ", $key)?> <span>*</span></label>
												<div class="col-sm-2">
													<select name="<?=$key?>" class="form-control required">
														<?php
															if ($Status=="0")
															{
														?>
																<option value="0" selected>Live</option>
																<option value="1">Offline</option>
														<?php
															}
															elseif ($Status=="1")
															{
														?>
																<option value="0">Live</option>
																<option value="1" selected>Offline</option>
														<?php
															}
															else
															{
														?>
																<option value="" selected>--Choose option--</option>
																<option value="0">Live</option>
																<option value="1">Offline</option>
														<?php
															}
														?>	
													</select>
												</div>
											</div>
											
<?php	
			}
			else
			{
?>
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Admin", " ", $key)?> <span>*</span></label>
												<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("Admin", " ", $key)?>" value="<?=$row[$key]?>"></div>
											</div>


<?php
			}
		}
	}
?>

											<?php
												$sql = "select ImagePath , EID FROM tblEmployeesImages where EID = '$strID'";
												$RS2 = $DB->query($sql);
												if ($RS2->num_rows > 0) 
												{
													while($row2 = $RS2->fetch_assoc())
													{
														$strImagePath = $row2["ImagePath"];
														
												?>		

													<div class="form-group">
														<label class="col-sm-3 control-label">Employee Image</label>
														<div class="col-sm-4"><img src="<?=$strImagePath?>" alt="<?=$strImagePath?>" width="100px"/>
														<hr>
															<input class="imageupload" type="file" data-source="ImagePath" name="ImagePath" id="fileSelect">
															Click to change the Employee Image
														</div>
													</div>
												<?php
													}
												}
												else
												{
												?>	
													<div class="form-group">
														<label class="col-sm-3 control-label">Employee Image<span>*</span>
														</label>
														<div class="col-sm-3">
															<input class="imageupload" type="file" data-source="ImagePath" name="ImagePath" id="fileSelect">
														</div>
													</div>
												<?php
												}
											?>

											<div class="form-group"><label class="col-sm-3 control-label"></label>
												<input type="submit" class="btn ra-100 btn-primary" value="Update">
												
												<div class="col-sm-1"><a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a></div>
											</div>
<?php
}
$DB->close();
?>													
										
									</div>
							</form>
							</div>
						</div>
                   </div>			
<?php
}
?>	                   
                </div>
            </div>
        </div>
		
        <?php require_once 'incFooter.fya'; ?>
		
    </div>
</body>

</html>