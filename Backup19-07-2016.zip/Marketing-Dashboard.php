<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once("incMetaScript.fya"); ?>
</head>

<body>
    <div id="sb-site">	
	
		<?php require_once("incOpenLayout.fya"); ?>
		
		
        <?php require_once("incLoader.fya"); ?>
		
		
        <div id="page-wrapper">
            <div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
				
				<?php require_once("incLeftMenu.fya"); ?>
				
            <div id="page-content-wrapper">
                <div id="page-content">

					<?php require_once("incMarketing-Header.fya"); ?>
				
                    <script type="text/javascript" src="assets/widgets/skycons/skycons.js"></script>
                    <script type="text/javascript" src="assets/widgets/datatable/datatable.js"></script>
                    <script type="text/javascript" src="assets/widgets/datatable/datatable-bootstrap.js"></script>
                    <script type="text/javascript" src="assets/widgets/datatable/datatable-tabletools.js"></script>
                    <script type="text/javascript">
                        /* Datatables basic */

                        $(document).ready(function() {
                            $('#datatable-example').dataTable();
                        });

                        /* Datatables hide columns */

                        $(document).ready(function() {
                            var table = $('#datatable-hide-columns').DataTable({
                                "scrollY": "300px",
                                "paging": false
                            });

                            $('#datatable-hide-columns_filter').hide();

                            $('a.toggle-vis').on('click', function(e) {
                                e.preventDefault();

                                // Get the column API object
                                var column = table.column($(this).attr('data-column'));

                                // Toggle the visibility
                                column.visible(!column.visible());
                            });
                        });

                        /* Datatable row highlight */

                        $(document).ready(function() {
                            var table = $('#datatable-row-highlight').DataTable();

                            $('#datatable-row-highlight tbody').on('click', 'tr', function() {
                                $(this).toggleClass('tr-selected');
                            });
                        });



                        $(document).ready(function() {
                            $('.dataTables_filter input').attr("placeholder", "Search...");
                        });
                    </script>
                    <script type="text/javascript" src="assets/widgets/charts/chart-js/chart-core.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/chart-js/chart-doughnut.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/chart-js/chart-demo-1.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot-resize.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot-stack.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot-pie.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot-tooltip.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/flot/flot-demo-1.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/sparklines/sparklines.js"></script>
                    <script type="text/javascript" src="assets/widgets/charts/sparklines/sparklines-demo.js"></script>
                    <link rel="stylesheet" type="text/css" href="assets/widgets/owlcarousel/owlcarousel.css">
                    <script type="text/javascript" src="assets/widgets/owlcarousel/owlcarousel.js"></script>
                    <script type="text/javascript" src="assets/widgets/owlcarousel/owlcarousel-demo.js"></script>
					
					
                    <div id="page-title">
                        <h2>Dashboard</h2>
                       
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-3"><a href="#" title="Example tile shortcut" class="tile-box tile-box-shortcut btn-danger"><span class="bs-badge badge-absolute">1000</span><div class="tile-header">Total SMS Send</div><div class="tile-content-wrapper"><i class="glyph-icon icon-file-photo-o"></i></div></a></div>
                                <div class="col-md-3">
                                   <a href="#" title="Example tile shortcut" class="tile-box tile-box-shortcut btn-danger"><span class="bs-badge badge-absolute">200</span><div class="tile-header">SMS Remaining</div><div class="tile-content-wrapper"><i class="glyph-icon icon-file-photo-o"></i></div></a>
                                </div>
                                <div class="col-md-3">
									<a href="#" title="Example tile shortcut" class="tile-box tile-box-shortcut btn-danger"><span class="bs-badge badge-absolute">500</span><div class="tile-header">Total Campaign</div><div class="tile-content-wrapper"><i class="glyph-icon icon-file-photo-o"></i></div></a>
								</div>
                                <div class="col-md-3">
                                    <a href="#" title="Example tile shortcut" class="tile-box tile-box-shortcut btn-danger"><span class="bs-badge badge-absolute">3</span><div class="tile-header">Total Offers</div><div class="tile-content-wrapper"><i class="glyph-icon icon-file-photo-o"></i></div></a>
                                </div>
                            </div>
                            <div class="panel mrg20T">
                                <div class="panel-body">
                                    <h3 class="title-hero">SMS Send</h3>
                                    <div class="example-box-wrapper">
                                        <div id="data-example-1" class="mrg20B" style="width: 100%; height: 300px"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-layout">
                        
                            </div>
                           
                        </div>
                        <div class="col-md-4">
                           
                            <div class="content-box">
                                <h3 class="content-box-header bg-default"><i class="glyph-icon icon-cog"></i> Live server status <span class="header-buttons-separator"><a href="#" class="icon-separator remove-button" data-animation="flipOutX"><i class="glyph-icon icon-times"></i></a></span></h3>
                                <div class="content-box-wrapper pad0A">
                                    <div class="mrg20A">
                                        <div class="row">
                                            <div class="col-md-7 center-margin pad0A"><canvas id="chart-area" width="150" height="150"></canvas></div>
                                        </div>
                                    </div>
                                    <table class="table remove-background">
                                        <tbody>
                                            <tr>
                                                <td class="text-left size-sm">
                                                    <div class="badge mrg10L badge-small mrg5R bg-azure"></div>New user registrations</td>
                                                
                                            </tr>
                                            <tr>
                                                <td class="text-left size-sm">
                                                    <div class="badge mrg10L badge-small mrg5R bg-orange"></div>Interested Users</td>
                                                
                                            </tr>
                                            <tr>
                                                <td class="text-left size-sm">
                                                    <div class="badge mrg10L badge-small mrg5R bg-gray"></div>Total Offers</td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<?php require_once 'incFooter.fya'; ?>
 
    </div>
</body>

</html>