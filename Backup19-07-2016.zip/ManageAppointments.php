<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<?php
	$strPageTitle = "Manage Appointments | NailSpa";
	$strDisplayTitle = "Manage Appointments for NailSpa";
	$strMenuID = "10";
	$strMyTable = "tblAppointments";
	$strMyTableID = "AppointmentID";
	$strMyField = "AppointmentDate";
	$strMyActionPage = "ManageAppointments.php";
	$strMessage = "";
	$sqlColumn = "";
	$sqlColumnValues = "";
	
// code for not allowing the normal admin to access the super admin rights	
	if($strAdminType!="0")
	{
		die("Sorry you are trying to enter Unauthorized access");
	}
// code for not allowing the normal admin to access the super admin rights	

	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$strStep = Filter($_POST["step"]);
		
		if($strStep=="add")
		{
			foreach($_POST as $key => $val)
			{
				if($key!="step")
				{
					if(IsNull($sqlColumn))
					{
						$sqlColumn = $key;
						$sqlColumnValues = "'".$_POST[$key]."'";
					}
					else
					{
						$sqlColumn = $sqlColumn.",".$key;
						$sqlColumnValues = $sqlColumnValues.", '".$_POST[$key]."'";
					}
				}
	
			}
			$strCustomerID = Filter($_POST["CustomerID"]);
			$strStoreID = Filter($_POST["StoreID"]);
			$strAppointmentDate = Filter($_POST["AppointmentDate"]);
			$strSuitableAppointmentTime = Filter($_POST["SuitableAppointmentTime"]);
			$strAppointmentCheckInTime = Filter($_POST["AppointmentCheckInTime"]);
			$strAppointmentCheckOutTime = Filter($_POST["AppointmentCheckOutTime"]);
			$strAppointmentOfferID = Filter($_POST["AppointmentOfferID"]);
			$strStatus = Filter($_POST["Status"]);


			$DB = Connect();
			$sql = "Select $strMyTableID from $strMyTable where $strMyField='$_POST[$strMyField]'";
			$RS = $DB->query($sql);
			if ($RS->num_rows > 0) 
			{
				$DB->close();
				die('<div class="alert alert-close alert-danger">
					<div class="bg-red alert-icon"><i class="glyph-icon icon-times"></i></div>
					<div class="alert-content">
						<h4 class="alert-title">Record Add Failed</h4>
						<p>Appointment Already Booked!</p>
					</div>
				</div>');
			}
			else
			{
				$sqlInsert = "INSERT INTO $strMyTable (CustomerID, StoreID, AppointmentDate, SuitableAppointmentTime, AppointmentCheckInTime, AppointmentCheckOutTime, AppointmentOfferID, Status) VALUES 
				('".$strCustomerID."', '".$strStoreID."', '".$strAppointmentDate."', '".$strSuitableAppointmentTime."', '".$strAppointmentCheckInTime."', '".$strAppointmentCheckOutTime."', '".$strAppointmentOfferID."', '".$strStatus."')";
				ExecuteNQ($sqlInsert);
				$DB->close();
				die('<div class="alert alert-close alert-success">
					<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
					<div class="alert-content">
						<h4 class="alert-title">Record Added Successfully.</h4>
					</div>
				</div>');
			}
		}

		if($strStep=="book")
		{
			foreach($_POST as $key => $val)
			{
				if($key!="step")
				{
					if(IsNull($sqlColumn))
					{
						$sqlColumn = $key;
						$sqlColumnValues = "'".$_POST[$key]."'";
					}
					else
					{
						$sqlColumn = $sqlColumn.",".$key;
						$sqlColumnValues = $sqlColumnValues.", '".$_POST[$key]."'";
					}
				}
	
			}
			$strCustomerID = Decode($_POST["CustomerID"]);
			$strStoreID = Filter($_POST["StoreID"]);
			$strAppointmentDate = Filter($_POST["AppointmentDate"]);
			$strSuitableAppointmentTime = Filter($_POST["SuitableAppointmentTime"]);
			$strAppointmentCheckInTime = Filter($_POST["AppointmentCheckInTime"]);
			$strAppointmentCheckOutTime = Filter($_POST["AppointmentCheckOutTime"]);
			$strAppointmentOfferID = Filter($_POST["AppointmentOfferID"]);
			$strStatus = Filter($_POST["Status"]);
			
			// Entry in tblAppointmentsDetails
			
			$strServiceID = Filter($_POST["ServiceID"]);
			
			$DB = Connect();
			//Retrieving cost for that particular service.
			$sql_ServiceCost = "SELECT ServiceID, ServiceCost FROM tblServices WHERE ServiceID = '".$strServiceID."'";
			$RS_ServiceCost = $DB->query($sql_ServiceCost);
			if ($RS_ServiceCost->num_rows > 0) 
			{
				$row_ServiceCost = $RS_ServiceCost->fetch_assoc();
				$strServiceCost = $row_ServiceCost['ServiceCost'];
			}
			else
			{
				$strServiceCost = '0';
			}
			
			
			$sqlInsert = "INSERT INTO tblAppointments (CustomerID, StoreID, AppointmentDate, SuitableAppointmentTime, AppointmentCheckInTime, AppointmentCheckOutTime, AppointmentOfferID, Status) VALUES 
			('".$strCustomerID."', '".$strStoreID."', '".$strAppointmentDate."', '".$strSuitableAppointmentTime."', '".$strAppointmentCheckInTime."', '".$strAppointmentCheckOutTime."', '".$strAppointmentOfferID."', '".$strStatus."')";
			// ExecuteNQ($sqlInsert);
			// echo $sqlInsert;
			// die();
			if ($DB->query($sqlInsert) === TRUE) 
			{
				$last_id = $DB->insert_id;		//last id of tblCustomers insert
			}
			else
			{
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
			
			// Inserting serviceID in tblAppointmentsDetails
			$sqlInsert1 = "INSERT INTO tblAppointmentsDetails (AppointmentID, ServiceID, ServiceAmount, Status) VALUES 
			('".$last_id."', '".$strServiceID."', '".$strServiceCost."', '0')";
			ExecuteNQ($sqlInsert1);
			
			
			
			
			$DB->close();
			die('<div class="alert alert-close alert-success">
				<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
				<div class="alert-content">
					<h4 class="alert-title">Appointment has been booked Successfully.</h4>
				</div>
			</div>');
		}
		
		if($strStep=="edit")
		{
			$DB = Connect();
			foreach($_POST as $key => $val)
			{
				if($key=="step" || $key==$strMyTableID)
				{
				
				}
				else
				{
					$sqlUpdate = "UPDATE $strMyTable SET $key='$_POST[$key]' WHERE $strMyTableID='".Decode($_POST[$strMyTableID])."'";
					ExecuteNQ($sqlUpdate);
				}
			}
			$DB->close();
			die('<div class="alert alert-close alert-success">
					<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
					<div class="alert-content">
						<h4 class="alert-title">Record Updated Successfully</h4>
					</div>
				</div>');
		}
		die();
	}	
	
if(isset($_GET['cin']) || isset($_GET['cout']) || isset($_GET['cid']))
{
	$DB = Connect();
	
	if(isset($_GET['cin']))
	{
		$sqlUpdate1 = "UPDATE $strMyTable SET AppointmentCheckInTime = CURTIME(), Status = '1' WHERE $strMyTableID='".DecodeQ($_GET['cin'])."'";
		ExecuteNQ($sqlUpdate1);
		header('Location: ManageAppointments.php');
	}
	elseif(isset($_GET['cout']))
	{
		$passingID1 = $_GET['cout'];
		$str = "Hello";
		$sqlUpdate1 = "UPDATE $strMyTable SET AppointmentCheckOutTime = CURTIME(), Status = '2' WHERE $strMyTableID='".DecodeQ($_GET['cout'])."'";
		$passingID = EncodeQ(DecodeQ($passingID1));
		ExecuteNQ($sqlUpdate1);
		header('Location: AppointmentDetails.php?aid='.$passingID);
	}
	elseif(isset($_GET['cid']))
	{
		$sqlUpdate1 = "UPDATE $strMyTable SET Status = '3' WHERE $strMyTableID='".DecodeQ($_GET['cid'])."'";
		ExecuteNQ($sqlUpdate1);
		header('Location: ManageAppointments.php');
	}
	else
	{
		header('Location: ManageAppointments.php');
	}
	$DB->close();
	
}

	
	
	
	


?>
<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once("incMetaScript.fya"); ?>
	
	
</head>

<body>
    <div id="sb-site">
        
		<?php require_once("incOpenLayout.fya"); ?>
		
		
        <?php require_once("incLoader.fya"); ?>
		
        <div id="page-wrapper">
            <div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
            
				<?php require_once("incLeftMenu.fya"); ?>
			
            <div id="page-content-wrapper">
                <div id="page-content">
                    
					<?php require_once("incHeader.fya"); ?>
					

                    <div id="page-title">
                        <h2><?=$strDisplayTitle?></h2>
                        <p>Re-schedule, Cancel Appointments</p>
                    </div>
<?php

if(!isset($_GET['uid']) && !isset($_GET['bid']) && !isset($_GET['vid']))
{
?>					
                    <div class="panel">
						<div class="panel">
							<div class="panel-body">
								
								<div class="example-box-wrapper">
									<div class="tabs">
										<ul>
											<li><a href="#normal-tabs-1" title="Tab 1">Manage</a></li>
										</ul>
											<div id="normal-tabs-1">
												<span class="form_result">&nbsp; <br>
											</span>
											
											<div class="panel-body">
												<h3 class="title-hero">List of Today's Appointments | NailSpa</h3>
												<div class="example-box-wrapper">
													<table id="datatable-responsive" class="table table-striped table-bordered responsive no-wrap" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th>Sr.No</th>
																<th>Customer Name<br>Mobile No.</th>
																<th>Store Name</th>
																<th>Appointment <br>Date & Time</th>
																<th>Check In<br>Check Out</th>
																<th>Offer ID</th>
																<th>Status</th>
																<th>Action</th>
															</tr>
														</thead>
														<tfoot>
															<tr>
																<th>Sr.No</th>
																<th>Customer Name<br>Mobile No.</th>
																<th>Store Name</th>
																<th>Appointment <br>Date & Time</th>
																<th>Check In<br>Check Out</th>
																<th>Offer ID</th>
																<th>Status</th>
																<th>Action</th>
															</tr>
														</tfoot>
														<tbody>

<?php
// Create connection And Write Values
$DB = Connect();
//Only today's appointments will be listed.
$sql = "SELECT * FROM ".$strMyTable." WHERE DATE(AppointmentDate) = CURDATE()";
$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{
	$counter = 0;

	while($row = $RS->fetch_assoc())
	{
		$counter ++;
		$strAppointmentID = $row["AppointmentID"];
		$getUID = EncodeQ($strAppointmentID);
		$getUIDDelete = Encode($strAppointmentID);	
		$strCustomerID = $row["CustomerID"];
		$strStoreID = $row["StoreID"];	
		$AppointmentDate = $row["AppointmentDate"];
		$SuitableAppointmentTime = $row["SuitableAppointmentTime"];
		$AppointmentCheckInTime = $row["AppointmentCheckInTime"];
		$AppointmentCheckOutTime = $row["AppointmentCheckOutTime"];
		$AppointmentOfferID = $row["AppointmentOfferID"];
		$Status = $row["Status"];
		
?>	
															<tr id="my_data_tr_<?=$counter?>">
																<td><?=$counter?></td>
																<td>
																<?
																$sql_cust = "SELECT * FROM tblCustomers WHERE CustomerID = '".$strCustomerID."'";
																$RS_cust = $DB->query($sql_cust);
																$row_cust = $RS_cust->fetch_assoc();
																$CustomerFullName = $row_cust['CustomerFullName'];
																$CustomerMobileNo = $row_cust['CustomerMobileNo'];
																echo "<b>Name : </b>".$CustomerFullName."<br> <b>Mobile No : </b>".$CustomerMobileNo;
																?>
																</td>
																
																<td>
																<?
																$sql_store = "SELECT * FROM tblStores WHERE StoreID = '".$strStoreID."'";
																$RS_store = $DB->query($sql_store);
																$row_store = $RS_store->fetch_assoc();
																$StoreName = $row_store['StoreName'];
																echo $StoreName;
																?>
																</td>
																
																<td><b>Date : </b><?=$AppointmentDate?><br><b>Time : </b><?=$SuitableAppointmentTime?></td>
																<td style="text-align:center">
																<?
																	if($AppointmentCheckInTime == "00:00:00" && $Status != '3')
																	{
																		?>
																			<a class="btn btn-link" href="<?=$strMyActionPage?>?cin=<?=$getUID?>">Check-In</a>
																		<?
																	}
																	elseif($AppointmentCheckInTime != "00:00:00" && $Status != '3')
																	{
																		echo "<b>In: </b>".$AppointmentCheckInTime;
																	}
																	elseif($Status == '3')
																	{
																		?>
																			<a class="btn btn-link disabled" href="<?=$strMyActionPage?>?cin=<?=$getUID?>">Check-In</a>
																		<?
																	}
																?>
																<br>
																<?
																	if($AppointmentCheckInTime != "00:00:00" )
																	{
																		if($AppointmentCheckOutTime == "00:00:00")
																		{
																			?>
																				<a class="btn btn-link" href="<?=$strMyActionPage?>?cout=<?=$getUID?>">Check-Out</a>

																			<?
																		}
																		else
																		{
																			echo "<b>Out: </b>".$AppointmentCheckOutTime;
																		}
																	}
																	elseif($AppointmentCheckInTime == "00:00:00" || $Status == "Cancelled" || $Status == '3')
																	{
																		?>
																			<a class="btn btn-link disabled" href="<?=$strMyActionPage?>?cout=<?=$getUID?>">Check-Out</a>
																		<?
																	}
																?>
																</td>
																<td><?=$AppointmentOfferID?></td>
																<td>
																	<?																		
																		if($Status=="0")
																		{
																			$Status = "Upcoming";
																		}
																		elseif($Status=="1")
																		{
																			$Status = "In Progress";
																		}
																		elseif($Status=="2")
																		{
																			$Status = "Done";
																		}
																		elseif($Status=="3")
																		{
																			$Status = "Cancelled";
																		}
																	echo $Status;
																	?>
																</td>
																<td style="text-align: center">
																	<?
																	if($Status == "Upcoming")
																	{
																	?>
																		<a class="btn btn-link" href="<?=$strMyActionPage?>?uid=<?=$getUID?>">Re-schedule</a><br>
																		<a class="btn btn-link" href="<?=$strMyActionPage?>?cid=<?=$getUID?>">Cancel</a>
																	<?
																	}
																	else
																	{
																	?>
																		<a class="btn btn-link disabled" href="<?=$strMyActionPage?>?uid=<?=$getUID?>">Re-schedule</a><br>
																		<a class="btn btn-link disabled" href="<?=$strMyActionPage?>?cid=<?=$getUID?>">Cancel</a>
																	<?	
																	}
																	?>
																</td>
															</tr>
															
<?php
	}
}
else
{
?>															
															<tr>
																<td></td>
																<td></td>
																<td></td>
																<td>No Records Found</td>
																<td></td>
																<td></td>
																<td></td>
																<td></td>
															</tr>
														
<?php
}
$DB->close();
?>
														
														</tbody>
													</table>
												</div>
											</div>
											<div class="fa-hover col-sm-3" style="float: right">	
												<a class="btn btn-primary btn-lg btn-block" href="ViewAppointments.php"><i class="fa fa-backward"></i> &nbsp; View all Appointments</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
                    </div>
<?php
} // End null condition


//-----------------Normal Edit

else
{
?>						
					
					<div class="panel">
						<div class="panel-body">
							<div class="fa-hover">	
								<a class="btn btn-primary btn-lg btn-block" href="javascript:window.location = document.referrer;"><i class="fa fa-backward"></i> &nbsp; Go back to <?=$strPageTitle?></a>
							</div>
						
							<div class="panel-body">
							<form role="form" class="form-horizontal bordered-row enquiry_form" onSubmit="proceed_formsubmit('.enquiry_form', '<?=$strMyActionPage?>', '.result_message', '', '.admin_email', '.admin_password'); return false;">
											
								<span class="result_message">&nbsp; <br>
								</span>
								<br>
<?
if(isset($_GET['uid']))
{
?>
								<input type="hidden" name="step" value="edit">
								<h3 class="title-hero">Re-Schedule Appointments</h3>
								<div class="example-box-wrapper">
										
<?php
$DB = Connect();
$strID = DecodeQ(Filter($_GET['uid']));
$sql_appointments = "SELECT * FROM tblAppointments WHERE AppointmentID='".$strID."'";

$RS_appointments = $DB->query($sql_appointments);
$Cust_ID;
if ($RS_appointments->num_rows > 0) 
{
	while($row_appointments = $RS_appointments->fetch_assoc())
	{
		foreach($row_appointments as $key => $val)
		{
			if($key=="AppointmentID")
			{
?>
											<input type="hidden" name="<?=$key?>" value="<?=Encode($strID)?>">
<?php
			}
			elseif($key=="StoreID")
			{	$DBvalue=$row_appointments[$key];
					
	?>	
												<div class="form-group">
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("StoreID", "Store Name", $key)?> <span>*</span></label>
												<div class="col-sm-4">	



<?php
													$sql = "SELECT StoreID, StoreName from tblStores where Status=0";
													$RS2 = $DB->query($sql);
													if ($RS2->num_rows > 0)
													{
?>
														<select class="form-control required" name="<?=$key?>">
<?
															while($row2 = $RS2->fetch_assoc())
															{
																$StoreID = $row2["StoreID"];
																$StoreName = $row2["StoreName"];
																if($DBvalue==$StoreID)
																{	
?>

																	<option value="<?=$StoreID?>" selected><?=$StoreName?></option>	
<?php
																}
																else
																{
?>

																	<option value="<?=$StoreID?>"><?=$StoreName?></option>	
<?php
																}
															}
?>
														</select>
<?php
													}
													else
													{
														echo "Stores Not Added <a href='ManageStores.php' target='Manage Stores'>Click here to add</a>";
													}
?>
												</div>
												</div>	
<?php
			}
			elseif($key=="AppointmentDate")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label">Appointment Date <span>*</span></label>
												<div class="col-sm-3">
													<input type="date" name="<?=$key?>" value="<?=$row_appointments[$key]?>" class="form-control required" placeholder="dd/mm/yyyy">
												</div>
											</div>	
<?php
			}
			elseif($key=="CustomerID")
			{
				$Cust_ID = $row_appointments[$key];
			}
			elseif($key=="SuitableAppointmentTime")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label">Suitable Time <span>*</span></label>
												<div class="col-sm-3">
													<input type="time" name="<?=$key?>" value="<?=$row_appointments[$key]?>" class="form-control required" placeholder="hh:mm AM/PM">
												</div>
											</div>	
<?php
			}
		}
		// echo $row_appointments['CustomerID'];
		$sql = "SELECT * FROM tblCustomers WHERE CustomerID = '".$Cust_ID."'";
		$RS = $DB->query($sql);
		if ($RS->num_rows > 0) 
		{
			while($row = $RS->fetch_assoc())
			{
				foreach($row as $key1 => $val1)
				{
					if($key1=="CustomerID")
					{
		?>
													<input type="hidden" name="<?=$key1?>" value="<?=Encode($strID)?>">	

		<?php
					}
					elseif($key1=="CustomerFullName")
					{
		?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("CustomerFullName", "Full Name", $key1)?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" readonly name="<?=$key1?>" class="form-control required" placeholder="<?=str_replace("CustomerFullName", "Full Name", $key1)?>" value="<?=$row[$key1]?>"></div>
													</div>
		<?php
					}
					elseif($key1=="CustomerMobileNo")
					{
		?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("CustomerMobileNo", "Mobile No.", $key1)?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" readonly name="<?=$key1?>" pattern="[0-9]{10}" title="Enter a valid mobile number!" class="form-control required" placeholder="<?=str_replace("CustomerMobileNo", "Mobile No.", $key1)?>" value="<?=$row[$key1]?>"></div>
													</div>
		<?php
					}
				}
			}
		}
	}
}
?>


											<div class="form-group"><label class="col-sm-3 control-label"></label>
												<input type="submit" class="btn ra-100 btn-primary" value="Update">
												
												<div class="col-sm-1"><a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a></div>
											</div>
										
											
											
											
											
<?php
}
elseif(isset($_GET['bid']))
{
?>
								<input type="hidden" name="step" value="book">
								<h3 class="title-hero">Book Appointments</h3>
								<div class="example-box-wrapper">
										
<?php
$DB = Connect();
$strID = DecodeQ(Filter($_GET['bid']));//Booking for customer with id=bid

$sql_appointments = "SELECT * FROM tblCustomers WHERE CustomerID='".$strID."'";
$RS_appointments = $DB->query($sql_appointments);
if ($RS_appointments->num_rows > 0) 
{
	while($row_appointments = $RS_appointments->fetch_assoc())
	{
		foreach($row_appointments as $key1 => $val1)
		{
			if($key1=="CustomerID")
			{
?>
											<input type="hidden" name="<?=$key1?>" value="<?=Encode($strID)?>">

<?php
			}
			elseif($key1=="CustomerFullName")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("CustomerFullName", "Full Name", $key1)?> <span>*</span></label>
												<div class="col-sm-3"><input readonly type="text" name="<?=$key1?>" class="form-control required" placeholder="<?=str_replace("CustomerFullName", "Full Name", $key1)?>" value="<?=$row_appointments[$key1]?>"></div>
											</div>
<?php
			}
			elseif($key1=="CustomerMobileNo")
			{
?>	
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("CustomerMobileNo", "Mobile No.", $key1)?> <span>*</span></label>
												<div class="col-sm-3"><input readonly type="text" name="<?=$key1?>" pattern="[0-9]{10}" title="Enter a valid mobile number!" class="form-control required" placeholder="<?=str_replace("CustomerMobileNo", "Mobile No.", $key1)?>" value="<?=$row_appointments[$key1]?>"></div>
											</div>
<?php
			}
		}
	}
		// Fields from tblAppointments Table
			
			$sql1 = "SELECT StoreID, StoreName FROM tblStores WHERE Status = 0";
			$RS2 = $DB->query($sql1);
			if ($RS2->num_rows > 0)
			{
?>
													<div class="form-group"><label class="col-sm-3 control-label">Appointment at <span>*</span></label>
															<div class="col-sm-3">
															<select class="form-control required"  name="StoreID" id="bidStoreID" onChange="storeservices(this.value);">
															<option value="" selected>-- Select Store --</option>
												<?
														while($row2 = $RS2->fetch_assoc())
														{
															$StoreID = $row2["StoreID"];
															$StoreName = $row2["StoreName"];	
												?>
															<option value="<?=$StoreID?>"><?=$StoreName?></option>
												<?php
														}
												?>
														</select>
															</div>
													</div>	
<?php
			}
			// $Store_ID = disp_services();
			$sql2 = "SELECT ServiceID, ServiceName, ServiceCost FROM tblServices WHERE Status = 0 ORDER BY StoreID";
			$RS3 = $DB->query($sql2);
			if ($RS3->num_rows > 0)
			{
?>
													<div class="form-group"><label class="col-sm-3 control-label">Appointment for <span>*</span></label>
															<div class="col-sm-3">
															<select class="form-control required"  name="ServiceID" id="ServiceID">
															<option value="" selected>-- Select Service --</option>
												<?
														while($row3 = $RS3->fetch_assoc())
														{
															$ServiceID = $row3["ServiceID"];
															$ServiceName = $row3["ServiceName"];
															$ServiceCost = $row3["ServiceCost"];
												?>
															<option value="<?=$ServiceID?>"><?=$ServiceName?>, Rs. <?=$ServiceCost?></option>
												<?php
														}
												?>
														</select># Charges exclusive of taxes
															</div>
													</div>	
<?php
			}
?>
														<div class="form-group"><label class="col-sm-3 control-label">Appointment Date <span>*</span></label>
															<div class="col-sm-3">
																<input type="date" name="AppointmentDate" class="form-control required" placeholder="dd/mm/yyyy">
															</div>
														</div>	
														
														<div class="form-group"><label class="col-sm-3 control-label">Suitable Time <span>*</span></label>
															<div class="col-sm-3">
																<input type="time" name="SuitableAppointmentTime" class="form-control required" placeholder="hh:mm AM/PM">
															</div>
														</div>															
	
<?	
}
?>


											<div class="form-group">
												<label class="col-sm-3 control-label"></label>
												<input type="submit" class="btn ra-100 btn-primary" value="Book">
												<div class="col-sm-1">
													<a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a>
												</div>
											</div>
<script>
	function storeservices(a1){
		// alert ('a1');
		var abc = a1;
		
		// alert (abc);
		$.ajax({
                url: "SelectServiceStoreWise.php",
                type: "POST",
                data: {
					StoreID: abc
				},
                success: function(data) {
					alert (data);
                    }
				
            });
	}
	</script>												
<?php
}
elseif(isset($_GET['vid']))
{
	echo "In VID";
	$DB = Connect();
	$strID = DecodeQ(Filter($_GET['vid']));
?>
							<div class="panel-body">
								<h3 class="title-hero">List of Appointments | NailSpa</h3>
								<div class="example-box-wrapper">
									<table id="datatable-responsive" class="table table-striped table-bordered responsive no-wrap" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>Sr.No</th>
												<th>Customer Name<br>Mobile No.</th>
												<th>Store Name</th>
												<th>Appointment <br>Date & Time</th>
												<th>Service</th>
												<th>Offer ID</th>
												<th>Status</th>
											</tr>
										</thead>
										<tfoot>
											<tr>
												<th>Sr.No</th>
												<th>Customer Name<br>Mobile No.</th>
												<th>Store Name</th>
												<th>Appointment <br>Date & Time</th>
												<th>Service</th>
												<th>Offer ID</th>
												<th>Status</th>
											</tr>
										</tfoot>
										<tbody>

							<?php
							// Create connection And Write Values
							$DB = Connect();
							//Only today's appointments will be listed.
							$sql = "SELECT * FROM ".$strMyTable." WHERE CustomerID = '".$strID."'";
							$RS = $DB->query($sql);
							if ($RS->num_rows > 0) 
							{
							$counter = 0;

							while($row = $RS->fetch_assoc())
							{
							$counter ++;
							$strAppointmentID = $row["AppointmentID"];
							$getUID = EncodeQ($strAppointmentID);
							$getUIDDelete = Encode($strAppointmentID);	
							$strCustomerID = $row["CustomerID"];
							$strStoreID = $row["StoreID"];	
							$AppointmentDate = $row["AppointmentDate"];
							$SuitableAppointmentTime = $row["SuitableAppointmentTime"];
							$AppointmentOfferID = $row["AppointmentOfferID"];
							$Status = $row["Status"];

							?>	
											<tr id="my_data_tr_<?=$counter?>">
												<td><?=$counter?></td>
												<td>
												<?
												$sql_cust = "SELECT * FROM tblCustomers WHERE CustomerID = '".$strCustomerID."'";
												$RS_cust = $DB->query($sql_cust);
												$row_cust = $RS_cust->fetch_assoc();
												$CustomerFullName = $row_cust['CustomerFullName'];
												$CustomerMobileNo = $row_cust['CustomerMobileNo'];
												echo "<b>Name : </b>".$CustomerFullName."<br> <b>Mobile No : </b>".$CustomerMobileNo;
												?>
												</td>
												
												<td>
												<?
												$sql_store = "SELECT * FROM tblStores WHERE StoreID = '".$strStoreID."'";
												$RS_store = $DB->query($sql_store);
												$row_store = $RS_store->fetch_assoc();
												$StoreName = $row_store['StoreName'];
												echo $StoreName;
												?>
												</td>
												
												<td><b>Date : </b><?=$AppointmentDate?><br><b>Time : </b><?=$SuitableAppointmentTime?></td>
												<td>
												<?
													$sql_Service = "SELECT * FROM tblAppointmentsDetails WHERE AppointmentID = '".$strAppointmentID."'";
													$RS_Service = $DB->query($sql_Service);
													$row_Service = $RS_Service->fetch_assoc();
													$ServiceID = $row_Service['ServiceID'];
													
													$sqlService = "SELECT * FROM tblServices WHERE ServiceID = '".$ServiceID."'";
													$RSService = $DB->query($sqlService);
													$rowService = $RSService->fetch_assoc();
													$ServiceName = $rowService['ServiceName'];
													
													echo $ServiceName;
												?>
												</td>
												<td><?=$AppointmentOfferID?></td>
												<td>
													<?																		
														if($Status=="0")
														{
															$Status = "Upcoming";
														}
														elseif($Status=="1")
														{
															$Status = "In Progress";
														}
														elseif($Status=="2")
														{
															$Status = "Done";
														}
														elseif($Status=="3")
														{
															$Status = "Cancelled";
														}
													echo $Status;
													?>
												</td>
											</tr>
											
							<?php
							}
							}
							else
							{
							?>															
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td>No Records Found</td>
												<td></td>
												<td></td>
												<td></td>
											</tr>
										
							<?php
							}
							$DB->close();
							?>
										
										</tbody>
									</table>
								</div>
							</div>
<?
}
?>													
										
									</div>
							</form>
							</div>
						</div>
                   </div>			
<?php
}
?>	                   
                </div>
            </div>
        </div>
        <?php require_once 'incFooter.fya'; ?>
		
    </div>
</body>

</html>