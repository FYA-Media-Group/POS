<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<?php
	
	$strERID1 = Filter($_POST["getERID"]);
	// echo $strERID1;
	// $strERID2= Decode($strERID1);
	// echo $strERID2;
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{	
		// echo $strERID1;
		$DB = Connect();
		
		$sql1 = "Update tblEmployeesRecords set LoginTime=now() where ERID ='$strERID1'";	
		// echo $sql1;
		if ($DB->query($sql1) === TRUE) 
		{
			// echo "Record Update successfully.";
			$sqlcheckout = "Select LoginTime, LogoutTime from tblEmployeesRecords where ERID ='$strERID1'";
			$RS1 = $DB->query($sqlcheckout);
			if ($RS1->num_rows > 0) 
			{
				$row1 = $RS1->fetch_assoc();
				$strLoginTime = $row1['LoginTime'];
				$strLogoutTime = $row1['LogoutTime'];
				if($LogoutTime=="00:00:00" && $LoginTime != "00:00:00")
				{
			
						echo '<div align="center"  id="CheckOut<?=$strERID?>">
							<a class=" btn btn-xs btn-primary  result_message1<?=$strERID?>" value="CheckOut" id="CheckOut" name="CheckOut" onclick="CheckOut(<?=$strERID?>);" >CheckOut</a>
						</div>';
			
				}
			}
			
		} 
		else 
		{
			echo "Error: " . $sql1 . "<br>" . $DB->error;
		}
	}
?>