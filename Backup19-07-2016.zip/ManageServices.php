<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>


<?php
	$strPageTitle = "Manage Services | Nailspa";
	$strDisplayTitle = "Manage Services for Nailspa";
	$strMenuID = "6";
	$strMyTable = "tblServices";
	$strMyTableID = "ServiceID";
	$strMyField = "ServiceName";
	$strMyActionPage = "ManageServices.php";
	$strMessage = "";
	$sqlColumn = "";
	$sqlColumnValues = "";
	
// code for not allowing the normal admin to access the super admin rights	
	if($strAdminType!="0")
	{
		die("Sorry you are trying to enter Unauthorized access");
	}
// code for not allowing the normal admin to access the super admin rights	

	
	
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$strStep = Filter($_POST["step"]);
		if($strStep=="add")
		{
			$strServiceName = Filter($_POST["ServiceName"]);
			$strServiceCode = Filter($_POST["ServiceCode"]);
			$strServiceCost = Filter($_POST["ServiceCost"]);
			$strServiceCommission = Filter($_POST["ServiceCommission"]);
			$strMRPLessTax = Filter($_POST["MRPLessTax"]);
			$strDirectCost = Filter($_POST["DirectCost"]);
			$strGMPercentage = Filter($_POST["GMPercentage"]);
			$strGrossMargin = Filter($_POST["GrossMargin"]);
			$strStatus = Filter($_POST["Status"]);
			$strStoreID = Filter($_POST["StoreID"]);
							
			$DB = Connect();
			$sql = "Select $strMyTableID from $strMyTable where $strMyField='$_POST[$strMyField]'";
			$RS = $DB->query($sql);
			if ($RS->num_rows > 0) 
			{
				$DB->close();
				die('<div class="alert alert-warning alert-dismissible fade in" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
						</button>
						<strong>The Service Code already exists in the system.</strong>
					</div>');
				die("");
			}
			else
			{
				$sqlInsert = "Insert into $strMyTable (ServiceName, ServiceCode, ServiceCost, ServiceCommission, MRPLessTax, DirectCost,GMPercentage, GrossMargin,  Status, StoreID) values
				('".$strServiceName."','".$strServiceCode."', '".$strServiceCost."', '".$strServiceCommission."', '".$strMRPLessTax."', '".$strDirectCost."', '".$strGMPercentage."', '".$strGrossMargin."', '".$strStatus."', '".$strStoreID."')";
				if ($DB->query($sqlInsert) === TRUE) 
				{
					$last_id = $DB->insert_id;
				}
				else
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
				
				$filepath = 'imageupload/images';
				CreateFolder($filepath);
				$strValidateImage1 = trim(ValidateImageFile2($_FILES, "ImageURL", UniqueStamp()."0".$_FILES["ImageURL"]["name"], $filepath));
				if($strValidateImage1=="Saved successfully")
				{
					// for First Image
					$filename1 = $_FILES["ImageURL"]["name"];
					
					$uploadFilename1 = UniqueStamp()."0".$filename1;		
					$strImageUploadPath1 = $filepath."/".$uploadFilename1;
					// #######################
				}
				else
				{
					die($strValidateImage1);
				}
				
				$sql1 = "Insert into tblServicesImages (ImageURL, ServiceID, Priority, isPrimary, Status) Values ('$strImageUploadPath1','$last_id', '1', '0', '0')";
				ExecuteNQ($sql1);
				$DB->Close();

				die('<div class="alert alert-close alert-success">
						<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
						<div class="alert-content">
							<h4 class="alert-title">Record Added Successfully</h4>
						</div>
					</div>');				
			}
		}	

	
		if($strStep=="edit")
		{
			
			$ServiceID = Filter($_POST["ServiceID"]);
			$ServiceName = Filter($_POST["ServiceName"]);
			$ServiceCode = Filter($_POST["ServiceCode"]);
			$ServiceCost = Filter($_POST["ServiceCost"]);
			$ServiceCommission = Filter($_POST["ServiceCommission"]);
			$MRPLessTax = Filter($_POST["MRPLessTax"]);
			$DirectCost = Filter($_POST["DirectCost"]);
			$GMPercentage = Filter($_POST["GMPercentage"]);
			$GrossMargin = Filter($_POST["GrossMargin"]);
			$GMPercentage = Filter($_POST["GMPercentage"]);
			$Status = Filter($_POST["Status"]);
			$StoreID = Filter($_POST["StoreID"]);
			
			if(isset($_FILES["ImageURL"]["error"]))
			{
				$strValidateImage1 = trim(ValidateImageFile($_FILES, "ImageURL"));
				if($strValidateImage1=="Saved successfully")
				{
				
					// As the image is valid first select the imagename for previous image
					
					$DB = Connect();
					$sql = "SELECT ImageURL, ServiceID FROM tblServicesImages WHERE $strMyTableID='".Decode($_POST[$strMyTableID])."' ";
					
					$RS = $DB->query($sql);
					if ($RS->num_rows > 0) 
					{
						while($row = $RS->fetch_assoc())
						{
							$strOldImageURL = $row["ImageURL"];	
							$strServiceID = $row["ServiceID"];
						}
						
						$file = $strOldImageURL;
						unlink($file);
						
						$filepath = 'imageupload/images';
						$filename1 = $_FILES["ImageURL"]["name"];
						
						$uploadFilename1 = UniqueStamp().$filename1;		
						$strImageUploadPath1 = $filepath."/".$uploadFilename1;
						// #######################
						
							
						
						$sqlUpdate = "UPDATE tblServicesImages SET ImageURL='".$strImageUploadPath1."' WHERE $strMyTableID='".Decode($_POST[$strMyTableID])."' ";
						ExecuteNQ($sqlUpdate);
							
						
						echo('<div class="alert alert-success alert-dismissible fade in" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
								</button>
								<strong>Service Image Updated Successfully</strong>
								</div>');						
					}
					else
					{
						$filepath = 'imageupload/images';
						// for First Image
						$filename1 = $_FILES["ImageURL"]["name"];
						
						$uploadFilename1 = UniqueStamp().$filename1;		
						$strImageUploadPath1 = $filepath."/".$uploadFilename1;
						// #######################
						
						$sql1 = "INSERT INTO tblServicesImages (ImageURL, ServiceID, Priority, isPrimary, Status) VALUES ('$strImageUploadPath1','".Decode($_POST[$strMyTableID])."', '1', '0', '0')";
						ExecuteNQ($sql1);
						
						echo('<div class="alert alert-success alert-dismissible fade in" role="alert">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
							</button>
							<strong>Service Image Added Successfully</strong>
							</div>');
					}					
					
				}
				else
				{
					die($strValidateImage1);
				}
				foreach($_POST as $key => $val)
				{
					if($key=="step" || $key==$strMyTableID ||  $key=="ImageURL" )
					{
					
					}
					else
					{
						$sqlUpdate = "UPDATE $strMyTable SET $key='$_POST[$key]' WHERE $strMyTableID='".Decode($_POST[$strMyTableID])."'";
						ExecuteNQ($sqlUpdate);
						//echo($sqlUpdate);
					}	
				}
				die('<div class="alert alert-close alert-success">
						<div class="bg-green alert-icon"><i class="glyph-icon icon-check"></i></div>
						<div class="alert-content">
							<h4 class="alert-title">Record Updated Successfully</h4>
						</div>
					</div>');
			}	
		}
		// die();
	}	
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once("incMetaScript.fya"); ?>
	
</head>

<body>
	<div id="sb-site">
        
		<?php require_once("incOpenLayout.fya"); ?>
		
		
        <?php require_once("incLoader.fya"); ?>
		
		<div id="page-wrapper">
			<div id="mobile-navigation"><button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button></div>
			<?php require_once("incLeftMenu.fya"); ?>
			
			<div id="page-content-wrapper">
				<div id="page-content">
                    
					<?php require_once("incHeader.fya"); ?>
					
					<div id="page-title">
                        <h2><?=$strDisplayTitle?></h2>
                        <p>Add, edit, delete Nailspa Services</p>
                    </div>
					
<?php

if(!isset($_GET["uid"]))
{	
?>				
				<div class="panel">
					<div class="panel">
							<div class="panel-body">
								
								<div class="example-box-wrapper">
									<div class="tabs">
										<ul>
											<li><a href="#normal-tabs-1" title="Tab 1">Manage</a></li>
											<li><a href="#normal-tabs-2" title="Tab 2">Add</a></li>
										</ul>
										<div id="normal-tabs-1">
										
											<span class="form_result">&nbsp; <br>
											</span>
											
											<div class="panel-body">
												<h3 class="title-hero">List of Services | Nailspa</h3>
												<div class="example-box-wrapper">
													<table id="datatable-responsive" class="table table-striped table-bordered responsive no-wrap" cellspacing="0" width="100%">
														<thead>
															<tr>
																<th>Sr. No</th>
																<th>Service Name <br> Service Code </th>	
																<th>Direct Cost</th>
																<th>Store Name</th>																
																<th>Status</th>
																<th>Actions</th>
															</tr>
														</thead>
														<tfoot>
															<tr>
																<th>Sr. No</th>
																<th>Service Name <br> Service Code </th>	
																<th>Direct Cost</th>
																<th>Store Name</th>																
																<th>Status</th>
																<th>Actions</th>
															</tr>
														</tfoot>
														<tbody>
<?php
// Create connection And Write Values
$DB = Connect();

$sql = "SELECT ServiceID, ServiceName, ServiceCode, ServiceCost, ServiceCommission, MRPLessTax, DirectCost, GMPercentage, GrossMargin, StoreID, Status from tblServices where Status='0'";
// echo $sql;

$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{
	$counter = 0;

	while($row = $RS->fetch_assoc())
	{
		$counter ++;
		$strServiceID = $row["ServiceID"];
		$getUID = EncodeQ($strServiceID);
		$getUIDDelete = Encode($strServiceID);
		$ServiceName = $row["ServiceName"];
		$ServiceCode = $row["ServiceCode"];
		$ServiceCost = $row["ServiceCost"];
		$ServiceCommission = $row["ServiceCommission"];
		$MRPLessTax = $row["MRPLessTax"];
		$DirectCost = $row["DirectCost"];
		$GMPercentage = $row["GMPercentage"];
		$GrossMargin = $row["GrossMargin"];
		$StoreID = $row["StoreID"];
		$Status =Filter($row["Status"]);
		
		$sql_StoreName = "SELECT StoreID, StoreName FROM tblStores WHERE StoreID = $StoreID";
		$RS_StoreName = $DB->query($sql_StoreName);
		$strStoreName;
		if($RS_StoreName->num_rows > 0)
		{
			$row_StoreName = $RS_StoreName->fetch_assoc();
			$strStoreName = $row_StoreName['StoreName'];
		}
		
		if($Status=="0")
		{
			$Status = "Live";
		}
		else
		{
			$Status = "Offline";
		}
		
		if($AdminType=="0")
		{
			$AdminType = "<font color='Purple'><b>Super Admin</b></font>";
		}
		else
		{
			$AdminType = "<font color='Red'><b>Admin</b></font>";
		}
?>	
												<tr id="my_data_tr_<?=$counter?>">
												<td><?=$counter?></td>
												<td><b>Name : </b><?=$ServiceName?> <br><b>Code : </b><?=$ServiceCode?> </td>
												
												<td><?=$ServiceCost?></td>
												
												<td><?=$strStoreName?></td>
												<td><?=$Status?></td>
												<td>
													<a class="btn btn-link" href="<?=$strMyActionPage?>?uid=<?=$getUID?>">Edit</a>
													
													<a class="btn btn-link font-red" font-redhref="javascript:;" onclick="DeleteData('Step11','<?=$getUIDDelete?>', 'Are you sure you want to delete this Stock - <?=$AdminFullName?>?','my_data_tr_<?=$counter?>');">Delete</a><br>
												</td>
											</tr>
<?php
	}
}
else
{
?>	
											<tr>
												<td></td>
												<td></td>
												<td>No Records Found</td>
												<td></td>
												<td></td>
												<td></td>
											</tr>
<?php
}
$DB->close();
?>
<!--TAB 2 START-->											
											</tbody>
													</table>
												</div>
											</div>
										</div>
										
										<div id="normal-tabs-2">
										
											<div class="panel-body">
											
												<form role="form" class="form-horizontal bordered-row enquiry_form" onSubmit="proceed_formsubmit('.enquiry_form', '<?=$strMyActionPage?>', '.result_message', '','.admin_email','', '.imageupload'); return false;">
											
												<span class="result_message">&nbsp; <br>
												</span>
											
												<input type="hidden" name="step" value="add">

													<h3 class="title-hero">Add New Service</h3>
													<div class="example-box-wrapper">
<?php
// Create connection And Write Values
$DB = Connect();
$sql = "SHOW COLUMNS FROM ".$strMyTable." ";
$RS = $DB->query($sql);
if ($RS->num_rows > 0) 
{

	while($row = $RS->fetch_assoc())
	{
		if($row["Field"]==$strMyTableID)
		{
		}
		else if ($row["Field"]=="ServiceName")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceName", "Service Name", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("ServiceName", "Service Name", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("POST", "Pedicure Normal, Menicure Normal ", $row["Field"])?>"></div>
													</div>													
<?php	
		}
		else if ($row["Field"]=="ServiceCode")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCode", "Service Code", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("ServiceCode", "Service Code", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("ServiceCode", "Pedicure001, menicure001", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="ServiceCost")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCost", "Cost", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("ServiceCost", "Cost", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("ServiceCost", "1000,2000", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="ServiceCommission")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCommission", "Commission", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("ServiceCommission", "Commission", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("ServiceCommission", "10% , 20%", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="MRPLessTax")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("MRPLessTax", "MRP Less Tax", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("MRPLessTax", "MRP Less Tax", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("MRPLessTax", "50, 5%", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="DirectCost")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("DirectCost", "DirectCost", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("DirectCost", "DirectCost", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("DirectCost", "800", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="GMPercentage")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("GMPercentage", "GM Percentage", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("GMPercentage", "GM Percentage", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("GMPercentage", "10%, 20%", $row["Field"])?>"></div>
													</div>	
<?php	
		}
		else if ($row["Field"]=="GrossMargin")
		{
?>	
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("GrossMargin", "Gross Margin", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("GrossMargin", "Gross Margin", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("GrossMargin", "500 , 1000", $row["Field"])?>"></div>
													</div>
<?php
		}
		else if($row["Field"]=="StoreID")
		{
											$sql1 = "SELECT StoreID, StoreName FROM tblStores WHERE Status=0";
											$RS2 = $DB->query($sql1);
											if ($RS2->num_rows > 0)
											{
?>											
													<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("StoreID", "Store Name", $row["Field"])?> <span>*</span></label>
														<div class="col-sm-4">
															<select class="form-control required"  name="<?=$row["Field"]?>">
																	<option value="" selected>--Select Store--</option>
<?
																		while($row2 = $RS2->fetch_assoc())
																		{
																			$StoreID = $row2["StoreID"];
																			$StoreName = $row2["StoreName"];	
?>
																			<option value="<?=$StoreID?>" ><?=$StoreName?></option>
<?php
																		}
?>
															</select>
<?php
											}
											else
											{
												echo "Stores Not Found <a href='ManageStores.php' target='ManageStores'>Click here to add</a>";
											}
?>
														</div>
													</div>	

<?php
		}
		else if ($row["Field"]=="Status")
		{
?>
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("POST", " ", $row["Field"])?> <span>*</span></label>
												<div class="col-sm-2">
													<select name="<?=$row["Field"]?>" class="form-control required">
														<option value="0" Selected>Live</option>
														<option value="1">Offline</option>	
													</select>
												</div>
											</div>
<?php	
		}
		else
		{
?>
											<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("POST", " ", $row["Field"])?> <span>*</span></label>
												<div class="col-sm-3"><input type="text" name="<?=$row["Field"]?>" id="<?=str_replace("POST", " ", $row["Field"])?>" class="form-control required" placeholder="<?=str_replace("POST", " ", $row["Field"])?>"></div>
											</div>
<?php
		}
	}
?>
											<div class="form-group"><label class="col-sm-3 control-label">Image<span>*</span></label>
												<div class="col-sm-4">
													<input type="file" class="form-control imageupload required" data-source="ImageURL" accept="image/*">
												</div>
											</div>
	
											<div class="form-group"><label class="col-sm-3 control-label"></label>
												<input type="submit" class="btn ra-100 btn-primary" value="Submit">
												
												<div class="col-sm-1"><a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a></div>
											</div>
<?php
}
$DB->close();
?>				
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
					</div>
                </div>
				
				
				
				
				
				
				
				
				
<?php
} // End null condition
	

	//Main Category - - Edit Start
	else
	{
	?>				
						<div class="panel">
							<div class="panel-body">
								<div class="fa-hover">	
									<a class="btn btn-primary btn-lg btn-block" href="<?=$strMyActionPage?>"><i class="fa fa-backward"></i> &nbsp; Go back to <?=$strPageTitle?></a>
								</div>
							
								<div class="panel-body">
									<form role="form" class="form-horizontal bordered-row enquiry_form" onSubmit="proceed_formsubmit('.enquiry_form', '<?=$strMyActionPage?>', '.result_message', '', '', '','.imageupload'); return false;">
												
									<span class="result_message">&nbsp; <br> </span>
									<br>
									<input type="hidden" name="step" value="edit">

									
										<h3 class="title-hero">Edit Services</h3>
										<div class="example-box-wrapper">
	<?php

	$strID = DecodeQ(Filter($_GET["uid"]));
	$DB = Connect();
	$sql = "select * FROM $strMyTable where $strMyTableID = '$strID'";
	$RS = $DB->query($sql);
	if ($RS->num_rows > 0) 
	{

		while($row = $RS->fetch_assoc())
		{
			foreach($row as $key => $val)
			{
				if($key==$strMyTableID)
				{										
	?>
												<input type="hidden" name="<?=$key?>" value="<?=Encode($strID)?>">	
	<?php
				}
				elseif($key=="StoreID")
				{
					$DBvalue=$row[$key];
					
	?>	
												<div class="form-group">
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("StoreID", "Store Name", $key)?> <span>*</span></label>
												<div class="col-sm-4">	



<?php
													$sql = "SELECT StoreID, StoreName from tblStores where Status=0";
													$RS2 = $DB->query($sql);
													if ($RS2->num_rows > 0)
													{
?>

														<select class="form-control required" name="<?=$key?>">
<?
									
										
															while($row2 = $RS2->fetch_assoc())
															{
																$StoreID = $row2["StoreID"];
																$StoreName = $row2["StoreName"];
																if($DBvalue==$StoreID)
																{	
?>

																	<option value="<?=$StoreID?>" selected><?=$StoreName?></option>	
<?php
																}
																else
																{
?>

																	<option value="<?=$StoreID?>"><?=$StoreName?></option>	
<?php
																}
															}
?>
														</select>
<?php
													}
													else
													{
														echo "Stores Not Added <a href='ManageStores.php' target='Manage Stores'>Click here to add</a>";
													}
?>
												</div>
												</div>	
<?php
			}
			elseif($key=="ServiceName")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceName", "Service Name", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("ServiceName", "Service Name", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="ServiceCode")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCode", "Service Code", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input readonly type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("ServiceCode", "Service Code", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="ServiceCost")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCost", "Service Cost", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("ServiceCost", "Service Cost", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="ServiceCommission")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("ServiceCommission", "Commission", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("ServiceCommission", "Commission", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="MRPLessTax")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("MRPLessTax", "MRP Less Tax", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("MRPLessTax", "MRP Less Tax", $key)?>" value="<?=$row[$key]?>"></div>
												</div>												
<?php
			}
			elseif($key=="DirectCost")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("DirectCost", "Direct Cost", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("DirectCost", "Direct Cost", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="GMPercentage")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("GMPercentage", "GM Percentage", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("GMPercentage", "GM Percentage", $key)?>" value="<?=$row[$key]?>"></div>
												</div>	
<?php
			}
			elseif($key=="GrossMargin")
			{
?>	
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("GrossMargin", "Gross Margin", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("GrossMargin", "Gross Margin", $key)?>" value="<?=$row[$key]?>"></div>
												</div>
<?php
			}
			elseif($key=="Status")
			{
?>
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Status", "Status", $key)?> <span>*</span></label>
													<div class="col-sm-2">
														<select name="<?=$key?>" class="form-control required">
															<?php
																if ($row[$key]=="0")
																{
															?>
																	<option value="0" selected>Live</option>
																	<option value="1">Offline</option>
															<?php
																}
																elseif ($row[$key]=="1")
																{
															?>
																	<option value="0">Live</option>
																	<option value="1" selected>Offline</option>
															<?php
																}
																else
																{
															?>
																	<option value="" selected>--Choose option--</option>
																	<option value="0">Live</option>
																	<option value="1">Offline</option>
															<?php
																}
															?>	
														</select>
													</div>
												</div>
<?php	
			}
			else
			{
?>
												<div class="form-group"><label class="col-sm-3 control-label"><?=str_replace("Admin", " ", $key)?> <span>*</span></label>
													<div class="col-sm-3"><input type="text" name="<?=$key?>" class="form-control required" placeholder="<?=str_replace("Admin", " ", $key)?>" value="<?=$row[$key]?>"></div>
												</div>
	<?php
				}
			}
		}
	?>
											<?php
												$sql_image = "SELECT ImageURL, ServiceID FROM tblServicesImages WHERE ServiceID = '$strID'";
												$RS2_image = $DB->query($sql_image);
												if ($RS2_image->num_rows > 0) 
												{
													while($row2_image = $RS2_image->fetch_assoc())
													{
														$strImageURL = $row2_image["ImageURL"];
														
												?>		

													<div class="form-group">
														<label class="col-sm-3 control-label">Service Image</label>
														<div class="col-sm-4"><img src="<?=$strImageURL?>" alt="<?=$strImageURL?>" width="100px"/>
														<hr>
															<input class="imageupload" type="file" data-source="ImageURL" name="ImageURL" id="fileSelect" value="Change Image" accept="image/*">
															Click to change the Employee Image
														</div>
													</div>
												<?php
													}
												}
												else
												{
												?>	
													<div class="form-group">
														<label class="col-sm-3 control-label">Service Image<span>*</span>
														</label>
														<div class="col-sm-3">
															<input class="imageupload" type="file" data-source="ImageURL" name="ImageURL" id="fileSelect" accept="image/*">
														</div>
													</div>
												<?php
												}
											?>
	
	
	
	
	

												<div class="form-group"><label class="col-sm-3 control-label"></label>
													<input type="submit" class="btn ra-100 btn-primary" value="Update">
													
													<div class="col-sm-1"><a class="btn ra-100 btn-black-opacity" href="javascript:;" onclick="ClearInfo('enquiry_form');" title="Clear"><span>Clear</span></a></div>
												</div>
	<?php
	}
	$DB->close();
	?>													
											
											</div>
									</form>
								</div>
							</div>
						</div>			
	<?php
	}
?>                   
					</div>
				</div>
			</div>
		
        <?php require_once 'incFooter.fya'; ?>
		</div>
    </div>
</body>

</html>									