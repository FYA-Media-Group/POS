<?php

			$strFrom = "saiffya@hotmail.com";
			$strSubject = "testing";
			$strBodysa = '<table style="BORDER-BOTTOM:#d0ac52 1px solid;BORDER-LEFT:#d0ac52 1px solid;BORDER-TOP:#d0ac52 1px solid;BORDER-RIGHT:#d0ac52 1px solid;background: url("http://nailspaexperience.com/images/test2.png") no-repeat;background-position: 50% -55px;" border="0" cellspacing="0" cellpadding="0" width="800" bgcolor="#ffffff" align="center">
                                    <tbody>
                                        <tr>
                                            <td align="middle">
                                                <table border="0" cellspacing="0" cellpadding="0" width="790" align="center">
                                                    <tbody>
                                                        <tr>
                                                            <td width="290" align="left" style="padding:1%;"><img border="0" src="http://nailspaexperience.com/header/Nailspa-logo.png" width="117" height="60" alt="NailSpa Experience"></td>
                                                            <td width="290" align="right" style="LINE-HEIGHT:15px; padding:1%; FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:12px;FONT-WEIGHT:normal;">
                                                                                                                        
                                                            A-2 Meherzin bldg,opp bank of India atm,next to ShilpaK,<br> woodhouse rd,Charag din lane, Colaba - 400005 <br>contact- 022 65320666
                                                            
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="LINE-HEIGHT:0;BACKGROUND:#d0ac52;FONT-SIZE:0px;" height="5"></td>
                                        </tr>
                                        <tr>
                                            <td style="PADDING-LEFT:10px;PADDING-RIGHT:10px;PADDING-TOP:10px;" align="left">
                                                <div style="BORDER-BOTTOM:#dedcdc 1px solid; FONT-FAMILY:Verdana,Geneva,sans-serif; BORDER-LEFT:#dedcdc 1px solid;PADDING-BOTTOM:15px;PADDING-LEFT:5px;PADDING-RIGHT:5px;BACKGROUND:#e4e4e4;FONT-SIZE:14px;BORDER-TOP:#dedcdc 1px solid;FONT-WEIGHT:bold;BORDER-RIGHT:#dedcdc 1px solid;PADDING-TOP:15px; text-align:center;">
                                                Login Details<br>
                                                                                                
                                                </div>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                        <td style="PADDING-LEFT:10px;PADDING-RIGHT:10px;" align="left">
                                        <!-- <div style="FONT-FAMILY:Verdana,Geneva,sans-serif; BORDER-LEFT:#dedcdc 1px solid;PADDING-BOTTOM:5px;PADDING-LEFT:5px;PADDING-RIGHT:5px;BACKGROUND:#e4e4e4;FONT-SIZE:14px;FONT-WEIGHT:bold;BORDER-RIGHT:#dedcdc 1px solid; text-align:center;">
                                               
                                                Oshiwara<br>
                                                
                                                
                                                </div> -->
                                        
                                        </td>
                                        </tr>
                                        
                                        <tr>
                                        <td style="PADDING-LEFT:10px;PADDING-RIGHT:10px;" align="left">
                                        <!-- <div style="FONT-FAMILY:Verdana,Geneva,sans-serif; BORDER-LEFT:#dedcdc 1px solid;PADDING-BOTTOM:5px;PADDING-LEFT:5px;PADDING-RIGHT:5px;BACKGROUND:#e4e4e4;FONT-SIZE:14px;FONT-WEIGHT:bold;BORDER-RIGHT:#dedcdc 1px solid; text-align:center;">
                                               
                                                Store # 542188200<br>
                                                
                                                
                                                </div> -->
                                        
                                        </td>
                                        </tr>
                                        
                                        <tr>
                                        <td style="PADDING-LEFT:10px;PADDING-RIGHT:10px;" align="left">
                                        <!-- <div style="FONT-FAMILY:Verdana,Geneva,sans-serif; BORDER-LEFT:#dedcdc 1px solid;PADDING-BOTTOM:5px;PADDING-LEFT:5px;PADDING-RIGHT:5px;BACKGROUND:#e4e4e4;FONT-SIZE:14px;FONT-WEIGHT:bold;BORDER-RIGHT:#dedcdc 1px solid; text-align:center;">
                                                
                                                15/7/2016 - 1:15 pm
                                                
                                                </div> -->
                                        
                                        </td>
                                        </tr>
                                        
                                        
                                        
                                        <tr>
                                            <td height="8"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                                    <tbody>
                                                        <tr>
                                                            <td style="PADDING-BOTTOM:8px;PADDING-LEFT:8px;PADDING-TOP:8px;" width="560">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="390" align="center">
                                                                    <tbody>
                                                                        <!--<tr>
                                                                            <td style="LINE-HEIGHT:25px;PADDING-LEFT:5px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" bgcolor="#ffffff" width="500" align="left">
                                                                            Invoice No: 6409
                                                                                                                                                       
                                                                            </td>
                                                                            <td style="LINE-HEIGHT:25px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;FONT-WEIGHT:normal;" bgcolor="#ffffff" align="right"></td>
                                                                        </tr>
                                                                        
                                                                        
                                                                        <tr>
                                                                            <td style="LINE-HEIGHT:25px;PADDING-LEFT:5px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" bgcolor="#ffffff" width="500" align="left">
                                                                            Membership no: OSH-98547689
                                                                           
                                                                            </td>
                                                                            <td style="LINE-HEIGHT:25px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;FONT-WEIGHT:normal;" bgcolor="#ffffff" align="right"></td>
                                                                        </tr>-->
                                                                        
                                                                        
                                                                        <tr>
                                                                            <td style="LINE-HEIGHT:25px;PADDING-LEFT:15px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" width="500" align="left">
                                                                       
                                                                            Login Id : testww
                                                                            
                                                                            </td>
                                                                            <td style="LINE-HEIGHT:25px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;FONT-WEIGHT:normal;" align="right"></td>
                                                                        </tr>
                                                                        
                                                                        
                                                                        <tr>
                                                                            <td style="LINE-HEIGHT:25px;PADDING-LEFT:15px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" width="500" align="left">                                                                            
                                                                            Password : saiffya@hotmail.com
                                                                            
                                                                            </td>
                                                                            <td style="LINE-HEIGHT:25px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;FONT-WEIGHT:normal;" align="right"></td>
                                                                        </tr>
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            
                                                            
                                                            <td style="PADDING-BOTTOM:8px;PADDING-RIGHT:8px;PADDING-TOP:8px;" width="460">
                                                                <table border="0" cellspacing="0" cellpadding="0" width="390" align="right">
                                                                    <tbody>
                                                                        <tr>
                                                                        	<td style="LINE-HEIGHT:25px;PADDING-LEFT:85px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" width="500" align="center">
                                                                            	Check The Admin panel Now
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="LINE-HEIGHT:25px;PADDING-LEFT:85px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;" width="500" align="left">
                                                                           <a href="http://nailspa.fyatest.website/pos/admin" class="log_in">Login</a>
                                                                                                                                                       
                                                                            </td>
                                                                            
                                                                        </tr>
                                                                        
                                                                        
                                                                        <tr>
                                                                            
                                                                            <td style="LINE-HEIGHT:25px;FONT-FAMILY:Verdana,Geneva,sans-serif;COLOR:#000;FONT-SIZE:14px;FONT-WEIGHT:normal;" align="right"></td>
                                                                        </tr>
                                                                        
                                                                        
                                                                      
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                            
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="8">
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                                    <tbody>
                                                        <tr>
                                                            <td bgcolor="#e4e4e4" height="4"></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                                
                                                </table>
                                            </td>
                                        </tr>
                                        
                                        
                                        <tr>
                                          
                                        </tr>
                                        <tr>
                                            <td>
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                                                                 
                                                </table>
                                            </td>
                                        </tr>
                                        
                                        
                                        <tr>
                                      
                                        </tr>
                                       
                                        <tr>
                                            <td>
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                              
                                     			</table>
                                            </td>
                                        </tr> 
                                  
                                        
                                        <tr>
                                            <td height="8"></td>
                                        </tr>
                                        
                                        
                                        <tr>
                                        
                                         <td style="BACKGROUND:#d0ac52;">
                                                <table border="0" cellspacing="0" cellpadding="0" width="780" align="center">
                                              
                                                <tbody>
                                        
                                            <tr><td width="33%" style="FONT-FAMILY:Arial,Helvetica,sans-serif;BACKGROUND:#d0ac52;COLOR:#000;FONT-SIZE:12px; padding:1%;" height="32" align="left">
                                            <span style="font-size:14px; font-weight:600;">CANDY</span><br>
                                            Sagar ville bldg,Bhulabhai desai marg, next to shree shardha restaurant, near mahalaxmi temple, Breach candy - 400026<br>
                                            
											contact- 022 65320001

                                            
                                            </td>
                                            <td width="33%" style="FONT-FAMILY:Arial,Helvetica,sans-serif;BACKGROUND:#d0ac52;COLOR:#000;FONT-SIZE:12px;" height="32" align="left">
                                            
                                            
                                            <span style="font-size:14px; font-weight:600;">KHAR</span><br>
                                            
                                            
                                            Jai Niketan bldg,grnd floor, opp Camy wafers,near Gabana, Khardanda 16th rd, Khar west - 400052<br>
											Contact- 022 65324444
                                            
                                            
                                            </td>
                                            <td width="33%" style="FONT-FAMILY:Arial,Helvetica,sans-serif;BACKGROUND:#d0ac52;COLOR:#000;FONT-SIZE:12px;" height="32" align="left">
                                            
                                            
                                            <span style="font-size:14px; font-weight:600;">ANDHERI</span><br>
                                            
                                            Park paradise bldg,opp windermere bldg, near green park, Oshiwara off link rd, Andheri west - 400053 <br>
											Contact- 022 65650099
                                            
                                            
                                            
                                            </td>
                                          
                                            </tr></tbody>
                                            </table>
                                            </td>
                                            
                                            
                                        	</tr>
                                    	</tbody>
                                	</table>';
									
			$headers = "From: $strFrom\r\n";
			$headers .= "Content-type: text/html\r\n";

		
			$retval = mail($strTo,$strSubject,$strBodysa,$headers);
           
			if( $retval == true )
			{
				echo "sent";
			}
			else
			{
				echo "not sent";
			}
			

?>