<?php require_once("setting.fya"); ?>
<?php require_once 'incFirewall.fya'; ?>

<?php
$typepie=$_POST['typepie'];
if($typepie=='1')
{
require_once("incChartsMetaScript.fya"); 

}
?>
	
